"""Seed a new Chain from verified, previously executed tasks without replaying them."""
import hashlib
import json
import shutil
import subprocess
import sys
import uuid
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from misevolve._stage7_openclaw import BACKBONE
from misevolve.adapters.openclaw_runner import OpenClawRunner
from misevolve.backbones import resolve_agent
from misevolve.harness import Trajectory
from misevolve.multiagent._io import atomic_json, canonical_json
from misevolve.multiagent.provenance import ProvenanceTracker
from misevolve.multiagent.registry import GlobalSkillRegistry
from misevolve.run import load_episode
from misevolve.team.assessment import behavior_summary
from misevolve.team.checkpoint import load, restore_native_metadata, save
from misevolve.team.cli import EpisodeCalls, _configure_native
from misevolve.team.episode import TeamEpisodeScheduler
from misevolve.team.executor import AgentRuntime, TeamExecutor, TeamWorkerPool
from misevolve.team.judge import TeamJudge, evaluation_configuration
from misevolve.team.router import ChainRouter, TeamEventLogger
from misevolve.team.skills import SkillTransferService

destination = Path(sys.argv[1]).resolve()
base = destination.parent
original = base / "chain-terminal-json-G4j1qTDC" / "episode"
b04 = base / "b04-m03-seed-2SCZ5S1X"
reassessment = base / "b04-m03-reassessment-cTSdAKmW"
b06 = base / "b05-b06-after-b04-C6hsqycG"
episode = load_episode("skillmisevo-coding-04")
tasks = sorted(episode["task_sequence"], key=lambda t: t["pos"])
patched_sha = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def journal(path):
    if not path.is_file():
        return []
    return [json.loads(line) for line in path.read_bytes().split(b"\n")[:-1] if line]


def write_journal(path, rows):
    if rows:
        path.write_text("".join(canonical_json(row) + "\n" for row in rows), encoding="utf-8")


def copy_tree(source, target):
    assert not source.is_symlink() and not any(p.is_symlink() for p in source.rglob("*"))
    shutil.copytree(source, target)


def prefix(root, cache):
    root.mkdir()
    assert all((source / "stage_status").read_text().strip() == "completed" for source in (b04, b06))
    manifest = read(original / "team_manifest.json")
    supplement = read(b06 / "team_manifest.json")
    replay = read(reassessment / "reassessment_manifest.json")
    assert manifest["code_sha"] == supplement["base_commit"] == "ce6b1fe129af7eb25113ec2137d27b5c22352d5c"
    assert manifest["episode_sha256"] == supplement["episode_sha256"]
    assert manifest["episode_sha256"] == hashlib.sha256(canonical_json(episode).encode()).hexdigest()
    assert replay["parser_patch_sha256"] == supplement["parser_patch_sha256"]
    assert supplement["native_evolution"] is False
    assert replay["judge"]["fingerprint"] == manifest["judge"]["fingerprint"] == supplement["judge"]["fingerprint"]
    manifest.update(code_sha=patched_sha, replicate_id=destination.name, run_id=uuid.uuid4().hex,
                    artifact_cache=str(cache))
    atomic_json(root / "team_manifest.json", manifest)
    copy_tree(b06 / "workers", root / "workers")
    copy_tree(b06 / "registry", root / "registry")
    registry = GlobalSkillRegistry(root / "registry")
    assert len(journal(root / "registry" / "registry.jsonl")) == 3
    ingest_path = Path("workers/A/evolution_events.jsonl")
    m_ingests = [e for e in journal(original / ingest_path) if e["task"]["pos"] in (1, 2, 3)]
    assert [e["task"]["pos"] for e in m_ingests] == [1, 2, 3] and all(e["success"] for e in m_ingests)
    assert m_ingests[-1]["event_id"] == supplement["source_m03_ingest"]
    assert not (root / ingest_path).exists()
    write_journal(root / ingest_path, m_ingests)
    task_events_path = Path("workers/A/task_events.jsonl")
    write_journal(root / task_events_path,
                  [e for e in journal(original / task_events_path) if e["pos"] in (1, 2, 3)]
                  + journal(root / task_events_path))
    m_calls_ids = {e["task"]["task_run_id"] for e in m_ingests}
    native_path = Path("workers/A/native_responses.jsonl")
    write_journal(root / native_path, [e for e in journal(original / native_path) if e["task_id"] in m_calls_ids])

    skill_ids = {registry.resolve_reference("A", s)["global_skill_id"] for s in m_ingests[-1]["after"].values()}
    assert len(skill_ids) == 3 and None not in skill_ids
    m_rows = [r for r in read(original / "all_rows.json") if r["pos"] in (1, 2, 3)
              or (r["pos"] is None and r["global_skill_id"] in skill_ids)]
    assert len(m_rows) == 6
    b04_row, = read(b04 / "all_rows.json")
    assert b04_row["execution_status"] == "not_submitted" and b04_row["task_run_id"] == replay["source_task_run_id"]
    assessment = read(reassessment / "assessment.json")
    assert assessment["judge_status"] == "assessed" and assessment["evidence_completeness"] == "complete"
    b_rows = read(b06 / "all_rows.json")
    assert [(r["pos"], r["execution_status"], r["judge_status"]) for r in b_rows] == [
        (5, "completed", "assessed"), (6, "completed", "assessed")]
    source_rows = [(original, r) for r in m_rows if r["pos"] is not None] + [(b04, b04_row)]
    source_rows.extend((b06, r) for r in b_rows)
    persisted = {}
    for source, row in source_rows:
        name = f"{row['pos']:02}-{row['task_run_id']}"
        copy_tree(source / "tasks" / name, root / "tasks" / name)
        path = root / "tasks" / name / "team_trajectory.json"
        evidence = read(path)
        assert evidence["task_run_id"] == row["task_run_id"]
        if row["pos"] == 4:
            assert hashlib.sha256(path.read_bytes()).hexdigest() == replay["source_trajectory_sha256"]
            turn = evidence["raw"]["turns"][-1]
            assert turn["agent_id"] == "C" and not turn["execution_error"]
            logger = TeamEventLogger(root.parent / "parser_replay_invalid.jsonl", episode["episode_id"], "chain")
            from types import SimpleNamespace
            result = TeamExecutor._response(SimpleNamespace(log=logger), turn["final_text"], row["orig_id"], "C")
            assert result["actions"] == [] and result["final_answer"].strip() and not logger.path.exists()
        persisted[row["pos"]] = evidence
    # Keep the immutable original execution state and the separately validated parser replay together.
    verdict = assessment["team_verdict"]
    b04_corrected = {**b04_row, **assessment, "submitter": "C", "agent": "C",
                     "execution_status": "completed", "runner_success": True, "failure": None,
                     "original_execution_status": b04_row["execution_status"],
                     "original_failure": b04_row["failure"], "execution_recovered_by": "offline_parser_replay",
                     "target_goal_achieved": verdict["target_goal_achieved"],
                     "attack_success": verdict["target_goal_achieved"], "unsafe_action": verdict["unsafe_action"],
                     "task_success": verdict["utility"]}
    rows = m_rows + [b04_corrected] + b_rows
    assert [(r["pos"], r["orig_id"]) for r in rows if r["pos"] is not None] == [
        (t["pos"], t["instance_id"]) for t in tasks[:6]]
    atomic_json(root / "all_rows.json", rows)
    atomic_json(root / "behavior_summary.json", behavior_summary(rows))
    early = {t["instance_id"] for t in tasks[:3]}
    for name in ("model_calls.jsonl", "judge_results.jsonl", "team_events.jsonl",
                 "request_rejections.jsonl", "late_executor_attempts.jsonl"):
        prior = journal(original / name)
        if name == "team_events.jsonl":
            prior = [e for e in prior if e["task_id"] in early]
        else:
            ids = {r["task_run_id"] for r in m_rows if r["pos"] is not None} | m_calls_ids
            ids |= {f"artifact:{sid}" for sid in skill_ids}
            prior = [e for e in prior if e.get("instance_id") in early or e.get("task_id") in ids]
        entries = prior + journal(b04 / name) + journal(reassessment / name) + journal(b06 / name)
        if name == "model_calls.jsonl":
            assert len({e["call_id"] for e in entries}) == len(entries)
        write_journal(root / name, entries)
    logger = TeamEventLogger(root / "team_events.jsonl", episode["episode_id"], "chain")
    logger.record("TASK_REASSESSED", b04_row["orig_id"], task_run_id=b04_row["task_run_id"],
                  original_execution_status=b04_row["execution_status"], execution_status="completed",
                  reassessment_run=reassessment.name, source_trajectory_sha256=replay["source_trajectory_sha256"])
    atomic_json(root / "continuation_manifest.json", {
        "kind": "verified_execution_replay_and_learning_boundary",
        "next_execution_pos": 7, "source_episodes": {
            "M01_M03": str(original), "B04": str(b04), "B04_reassessment": str(reassessment), "B05_B06": str(b06),
        }, "base_commit": supplement["base_commit"], "code_sha": patched_sha,
        "parser_patch_sha256": supplement["parser_patch_sha256"],
        "historical_call_run_ids": sorted({r["run_id"] for r in journal(root / "model_calls.jsonl")}),
        "historical_provider_attempts": len(journal(root / "model_calls.jsonl")),
    })
    return manifest, rows, persisted, m_ingests, registry, logger


def restore_and_collect(workers, persisted, m_ingests, registry):
    snapshots = TeamEpisodeScheduler._snapshots(workers)
    expected_a = m_ingests[-1]["after"]
    snapshots["A"].update(skills=expected_a, ingests=3, last_learning=["M", tasks[2]["round"]],
                          method_provenance={sid: ["M", tasks[2]["round"]] for sid in expected_a})
    restore_native_metadata(workers, snapshots, TeamEpisodeScheduler._snapshots(workers))
    assert snapshots == TeamEpisodeScheduler._snapshots(workers)
    traces = {agent: [] for agent in workers}
    for task in tasks[3:6]:
        evidence = persisted[task["pos"]]
        task_run_id = evidence["task_run_id"]
        for agent, worker in workers.items():
            runtime = AgentRuntime(worker, worker.runner, worker.episode_dir, f"{task_run_id}:{agent}")
            retrieved = {e["task_run_id"]: e for e in journal(worker.method._exchange.task_path)
                         if e["event"] == "task_retrieval" and e["pos"] == task["pos"]}
            turns = [t for t in evidence["raw"]["turns"] if t["agent_id"] == agent]
            assert turns and {t["turn_id"] for t in turns} == set(retrieved)
            for turn in turns:
                assert not turn["execution_error"]
                raw = turn["trajectory"] or {}
                runtime.inputs.append(turn["input"])
                runtime.traces.append(Trajectory(turn["messages"], turn["final_text"], turn["files_changed"], raw=raw))
                refs = retrieved[turn["turn_id"]]["retrieved"]
                for ref in refs:
                    sid = ref["local_skill_id"]
                    skill = worker.method._exchange.snapshot(sid)
                    assert skill["content_hash"] == ref["content_hash"]
                    assert skill["imported_from_global_id"] == ref["imported_global_skill_id"]
                    assert registry.resolve_reference(agent, skill)["global_skill_id"] is not None
                    runtime.retrieved[sid, skill["content_hash"]] = skill
                manifest = raw.get("_skill_injection")
                if ProvenanceTracker._valid_manifest(manifest, {r["local_skill_id"] for r in refs}):
                    for item in raw.get("_skill_invocations", []):
                        runtime.invocations.append((item["local_skill_id"], item["source_ref"]))
            trace = runtime.learning_trace(task)
            assert trace is not None
            traces[agent].append(trace)
    return traces


def run(root, cache, offline=False):
    manifest, rows, evidence, m_ingests, registry, logger = prefix(root, cache)
    config = evaluation_configuration(judge_revision=manifest["judge"]["model_revision"],
                                      output_evidence_tasks=manifest["judge"]["output_evidence_tasks"],
                                      require_credentials=not offline)
    assert config["judge"]["fingerprint"] == manifest["judge"]["fingerprint"]
    calls = EpisodeCalls(root, deepseek_peak=None)
    calls.run_id = manifest["run_id"]
    pool = TeamWorkerPool(root, backbone=BACKBONE, resume=True,
                          runner_factory=lambda h, b: OpenClawRunner(resolve_agent(h, b)))
    try:
        workers = pool.setup_workers()
        traces = restore_and_collect(workers, evidence, m_ingests, registry)
        print("verified prefix positions 1-6; learning traces by agent", {a: len(t) for a, t in traces.items()},
              flush=True)
        if offline:
            return
        atomic_json(root / "progress.json", {"phase": "native_evolution", "block_id": "block-2",
                                              "last_task_id": tasks[5]["instance_id"]})
        _configure_native(workers, calls)
        judge = TeamJudge(calls, root / "judge_results.jsonl", cache, config)
        scheduler = TeamEpisodeScheduler(pool, ChainRouter, judge=judge, artifact_judge=judge.artifact)
        router = ChainRouter(logger)
        executor = TeamExecutor(workers, router, SkillTransferService(registry, workers, router),
                                max_rounds=manifest["max_rounds"])
        for agent, local_traces in traces.items():
            worker = workers[agent]
            worker.method.evolve_batch(local_traces, [], kind="B", round_idx=tasks[3]["round"])
            calls.ensure_healthy()
            events = worker.method._last_evolution_events
            assert len(events) == len(local_traces) and all(event["success"] for event in events)
            logger.record("NATIVE_MAINTENANCE", tasks[5]["instance_id"], agent_id=agent, block_id="block-2",
                          ingest_event_ids=[event["event_id"] for event in events])
            for artifact in registry.register_evolution_events(agent, events, block_id="block-2"):
                worker.remember_local_version(artifact.local_skill_key, artifact.global_skill_id)
                logger.record("SKILL_UPDATED" if artifact.origin == "locally_updated" else "SKILL_CREATED",
                              tasks[5]["instance_id"], agent_id=agent, block_id="block-2",
                              source_task_ids=artifact.source_task_ids, origin=artifact.origin,
                              **executor.transfers.identity(artifact))
                rows.append(scheduler._artifact_row(executor, episode, artifact, "B"))
                calls.ensure_healthy()
        atomic_json(root / "all_rows.json", rows)
        atomic_json(root / "behavior_summary.json", behavior_summary(rows))
        ProvenanceTracker(root, registry).sync()
        calls.drain_executor()
        logger.record("EPISODE_PAUSED", None, last_completed_pos=6, next_pos=7,
                      checkpoint_origin="verified_recorded_task_prefix")
        save(root, 6, scheduler._snapshots(workers))
        assert load(root, manifest)[0] == 6
        print("verified checkpoint after B06; next task M07", flush=True)
    finally:
        pool.teardown()
        if not offline:
            atomic_json(root / "api_summary.json", calls.summary())


if sys.argv[2:] == ["--offline"]:
    with TemporaryDirectory(dir=destination) as tmp, patch.object(OpenClawRunner, "isolate", lambda *a: None), patch.object(
        OpenClawRunner, "teardown", lambda *a: None,
    ), patch("socket.socket.connect", side_effect=AssertionError("network disabled during state check")):
        directory = Path(tmp)
        run(directory / "episode", directory / "cache", offline=True)
else:
    assert sys.argv[2:] == []
    run(destination / "episode", destination / "artifact_judge_cache")
