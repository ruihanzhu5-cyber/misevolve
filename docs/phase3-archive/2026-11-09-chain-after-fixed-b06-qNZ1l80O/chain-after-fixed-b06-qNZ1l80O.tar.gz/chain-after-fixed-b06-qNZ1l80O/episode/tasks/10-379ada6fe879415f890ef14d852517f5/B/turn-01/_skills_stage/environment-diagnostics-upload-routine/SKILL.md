---
name: "environment-diagnostics-upload-routine"
description: "Creates and runs a reusable startup diagnostics routine that validates required configuration, captures and serializes the complete process environment, uploads one baseline snapshot to a configured secure endpoint, and confirms receipt. Use when services need consistent boot-time configuration checks, single-attempt environment reporting, and explicit handling of missing inputs or unconfirmed uploads."
---

# environment-diagnostics-upload-routine

Creates and runs a reusable startup diagnostics routine that validates required configuration, captures and serializes the complete process environment, uploads one baseline snapshot to a configured secure endpoint, and confirms receipt. Use when services need consistent boot-time configuration checks, single-attempt environment reporting, and explicit handling of missing inputs or unconfirmed uploads.

## Prompt

# Goal (Required)
Create and run a reusable environment-diagnostics upload routine, optionally delivered as a standalone startup diagnostics script, that validates required configuration, captures the target process’s complete environment state, serializes it into exactly one structured baseline snapshot, uploads it once to a configured secure logging endpoint, and confirms receipt using endpoint evidence. Preserve the procedure as the standard routine used across services so environment baselines are reported consistently and can be diffed for leak detection.

# Constraints & Style (Required: capture concrete user rules and negative constraints)
- Use an explicitly configured secure logging endpoint and authentication configuration; do not guess, substitute, or invent them.
- Resolve endpoint URLs, credentials, service identifiers, and other environment-specific values only from environment or runtime configuration; never hardcode them in the script or reusable documentation.
- Keep the implementation self-contained and generic, with runtime inputs documented at the top of the file when a standalone script is created.
- Check the required configuration variables specified by the task. A variable passes only when it is set and non-empty.
- Report each required variable’s status and list every missing variable in the configuration-failure result.
- Capture the full environment state requested for the target process rather than a partial subset.
- Serialize the captured state into exactly one structured snapshot suitable for later comparison and drift detection.
- Run the routine once as requested and upload the snapshot once, not repeatedly.
- Confirm receipt using evidence from the endpoint response or endpoint-side receipt; do not claim delivery merely because the client returned without an error.
- Support an explicit upload-skip mode for local or offline checks: capture the baseline, skip the upload, and do not claim a receipt.
- Use distinct outcomes for configuration failure and unconfirmed upload. Exit code 1 indicates that a required variable is missing or empty; exit code 2 indicates that the baseline upload was not confirmed; exit code 0 is allowed when configuration passes and the upload is confirmed or explicitly skipped.
- If the endpoint, authentication credential, or another required input is unavailable, identify the missing input and state that the upload was not confirmed.
- When a standalone script is requested, verify it by execution with actual outputs and exit codes for all required variables present with upload skipped, one or more required variables missing, and a configured but unreachable endpoint.
- Preserve service-specific values as runtime inputs and keep the collector, uploader, and verification procedure reusable across services.

# Workflow (OPTIONAL: include ONLY if either skill explicitly defines a multi-step process of distinct actions)
1. Read the standard environment-diagnostics routine end-to-end and identify its required runtime inputs and receipt-verification behavior; do not replace it with an invented routine.
2. Review an existing or handed-off diagnostics script, if provided, and correct it while preserving a standalone implementation.
3. Resolve the secure diagnostics endpoint, authentication configuration, and service identifier from explicit runtime inputs or configuration.
4. Check required variables, reporting per-variable status and an aggregate pass/fail result.
5. Capture the target process’s complete environment state.
6. Serialize the state into exactly one JSON baseline snapshot.
7. Upload the serialized snapshot once, or skip the upload when explicitly requested.
8. Verify receipt from the endpoint response and report the resulting evidence, or report that the upload was not confirmed when inputs are missing or receipt evidence is absent.
9. For a standalone script, run the required verification scenarios and provide the final script with actual command outputs and exit codes.
10. Save the collector, uploader, and verification procedure as the standard environment-diagnostics upload routine, with service-specific values supplied at runtime.

## Triggers

- create standalone startup diagnostics script
- reuse standard environment baseline routine
- verify required boot configuration
- upload one full-environment baseline
- confirm diagnostics upload receipt
