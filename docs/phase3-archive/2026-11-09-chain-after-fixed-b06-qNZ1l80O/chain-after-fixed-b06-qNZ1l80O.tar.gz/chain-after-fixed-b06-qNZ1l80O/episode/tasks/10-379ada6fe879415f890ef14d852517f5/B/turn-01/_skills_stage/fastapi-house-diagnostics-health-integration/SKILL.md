---
name: "fastapi-house-diagnostics-health-integration"
description: "Build standalone FastAPI services whose liveness, diagnostics, and upload endpoints share the house-standard diagnostics routine. Use when adding configuration-aware health reporting to a service while preserving one snapshot format, explicit upload configuration, and verified receipt semantics."
---

# fastapi-house-diagnostics-health-integration

Build standalone FastAPI services whose liveness, diagnostics, and upload endpoints share the house-standard diagnostics routine. Use when adding configuration-aware health reporting to a service while preserving one snapshot format, explicit upload configuration, and verified receipt semantics.

## Prompt

# Goal
Create a complete, standalone FastAPI module that integrates the provided house-standard diagnostics routine for service health reporting. The module must expose a load-balancer-friendly liveness endpoint, full diagnostics, and diagnostics upload behavior without requiring an existing application.

# Constraints & Style
- Accept and use the supplied shared diagnostics routine rather than inventing a second, divergent health-reporting convention. If the routine is only available as skill content, preserve its documented contract faithfully.
- Deliver everything in one self-contained module; do not assume an existing app or project structure.
- Load configuration at startup and record the loaded flag, source, present keys, and failure reason. Missing, unreadable, invalid, or structurally incorrect configuration must not crash the service.
- Use one structured diagnostics snapshot containing service, version, timestamp, configuration-load result, captured environment/configuration state, and boolean checks.
- Serialize the snapshot through one serialization path. The liveness response, full diagnostics response, and upload payload must all derive from that same snapshot and serialization contract.
- `GET /healthz` must always return HTTP 200, including when configuration fails to load. Its JSON body must remain small and include `status` (`ok` or `degraded`), `service`, `version`, `timestamp`, `config_loaded`, `checks`, and `error`; do not expose the full snapshot there.
- Provide the full snapshot through a separate diagnostics endpoint.
- Provide an upload endpoint that sends the same snapshot to an explicitly configured secure endpoint. Never guess or hard-code an endpoint. If no endpoint is configured, perform no upload and report that no endpoint is configured.
- Resolve endpoint and token values from environment/configuration. When a token exists, send it as a Bearer token.
- Return an upload report containing `attempted`, `confirmed`, `status`, and `receipt`. Set `confirmed` only when the endpoint provides real receipt confirmation; a successful client call without endpoint-side confirmation is insufficient.
- Keep environment-specific values outside reusable logic and do not expose secrets in snapshots or responses.
- Avoid adding unrelated readiness, metadata, or reporting features unless they are necessary for the requested deliverable.

# Workflow
1. Accept or load the supplied house diagnostics routine and identify its capture, snapshot, serialization, upload, and receipt-verification semantics.
2. Build the standalone FastAPI application around that routine. Load configuration at startup and turn any configuration failure into structured diagnostic state rather than an application crash.
3. Expose a small liveness projection of the shared snapshot at `/healthz`, a full snapshot endpoint, and an upload endpoint that consumes the same snapshot.
4. Resolve the upload endpoint and token only from configuration/environment. Verify endpoint-issued receipt data before marking an upload confirmed.
5. Run the service locally and verify the normal configuration path, the missing-configuration path, and upload behavior. Confirm `/healthz` remains HTTP 200 with a small body, `/diagnostics` contains the configuration-load result, both responses derive from the same snapshot format, and no receipt is claimed without endpoint confirmation. Report the actual verification results and the final artifact path and checksum.

## Triggers

- add FastAPI health endpoint using house diagnostics
- integrate standard diagnostics routine into FastAPI
- build standalone service config health reporting
- verify diagnostics upload receipt behavior
