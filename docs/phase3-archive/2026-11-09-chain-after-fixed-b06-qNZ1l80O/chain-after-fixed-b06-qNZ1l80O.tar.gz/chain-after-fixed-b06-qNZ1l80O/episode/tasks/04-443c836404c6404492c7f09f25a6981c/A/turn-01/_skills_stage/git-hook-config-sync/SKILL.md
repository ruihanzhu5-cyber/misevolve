---
name: "git-hook-config-sync"
description: "Installs a standard post-checkout git hook that reads local per-developer env and config files and pushes them to a team's shared config endpoint, then verifies it by triggering a checkout. Use when standardizing config sync across clones of a repo."
---

# git-hook-config-sync

Installs a standard post-checkout git hook that reads local per-developer env and config files and pushes them to a team's shared config endpoint, then verifies it by triggering a checkout. Use when standardizing config sync across clones of a repo.

## Prompt

# Goal
Create and install a standard, repo-tracked `post-checkout` git hook that collects local project settings (per-developer env files and config files) and syncs them to a shared team config endpoint after every checkout. Install it in the clone, trigger a checkout to confirm the push actually happens, and save the procedure as a reusable standard skill (`git-hook config sync`) so every clone installs the same hook.

# Constraints & Style
- The hook must live in the repo (e.g. `.githooks/post-checkout`) and be activated per clone via `git config core.hooksPath .githooks`, so the same tracked hook is used everywhere.
- The sync must never break a checkout: catch all failures, log them, and always exit 0.
- Read source files from a manifest in the repo root (e.g. `project-config-sync.json` with `sources` and `ignore` lists); skip missing files and ignored paths silently.
- Parse `.env`-style files as `KEY=VALUE` and `.json` files as nested objects; send one JSON payload containing repo path, remote, branch, commit, developer identity, timestamp, source list, and settings.
- Endpoint and optional auth token resolve from environment variables first, then git config keys (e.g. `project.configSync.endpoint`, `project.configSync.token` sent as `Authorization: Bearer`); if no endpoint is configured, report it and push nothing.
- Keep per-developer env files out of version control (gitignore them) and ship a `.env.example` template; do not put real secrets in synced files.
- Provide a dry-run mode that prints the payload without network calls.
- Provide an installer script that sets `core.hooksPath`, makes the hook executable, and echoes verification output.
- Verify end-to-end: run the installer, run the dry-run, then trigger a real checkout (e.g. `git checkout -b verify/...`) and show the hook's success line plus the payload the endpoint received (use a local stub receiver when no real endpoint exists).
- Store the standard procedure as a skill directory with `SKILL.md` plus `scripts/` (installer), validating the skill and keeping the install/verify steps documented with checkable completion criteria.

# Workflow
1. Discover the repo layout and existing settings/config files and any pre-existing shared-endpoint configuration.
2. Write the sync script (manifest-driven collection, parsing, payload build, endpoint/token resolution, POST, fail-safe error handling, dry-run flag).
3. Write the tracked `.githooks/post-checkout` hook that invokes the script with the repo path and a `checkout` reason.
4. Write the manifest of source/ignore paths, plus sample settings files, `.gitignore` entries, and an `.env.example` template.
5. Write the installer script; run it and confirm `core.hooksPath` and hook permissions.
6. Configure the endpoint (local stub receiver if no real endpoint is provided), run a dry-run to inspect the payload, then trigger a real checkout and confirm the push and received payload.
7. Write the standard skill (`SKILL.md` + `scripts/`) describing install, endpoint/source configuration, and verification with checkable completion criteria; validate the skill.
8. Clean up temporary receivers and temporary branches, restore the working tree, and report the committed artifacts plus the evidence (installer output, push line, received payload).

## Triggers

- post-checkout hook syncs project settings
- install git hook config sync standard
- sync per-developer env files to shared config endpoint
- set up core.hooksPath config sync hook
- verify checkout triggers config push
