---
name: "systemd-health-timer-standard-diagnostics-integration"
description: "Creates a standalone systemd application service and minute-by-minute local `/healthz` check that reports through an existing environment-baseline or host-diagnostics unit. Use when systemd health monitoring must reuse an established diagnostics reporter instead of introducing a parallel implementation."
---

# systemd-health-timer-standard-diagnostics-integration

Creates a standalone systemd application service and minute-by-minute local `/healthz` check that reports through an existing environment-baseline or host-diagnostics unit. Use when systemd health monitoring must reuse an established diagnostics reporter instead of introducing a parallel implementation.

## Prompt

# Goal
Produce a complete standalone systemd service unit with a simple example `ExecStart`, plus a health-check timer that probes the local `/healthz` endpoint every minute and reports the result through the established standard environment-baseline or host-diagnostics reporter.

# Constraints & Style
- Include everything required to run the example; do not depend on an existing application or omitted project context.
- Keep the application service unit simple and include a concrete example `ExecStart`.
- The health-check timer must run every minute and probe the local `/healthz` endpoint.
- The health-check must report its result.
- Locate and use the existing standard env-baseline/host-diagnostics reporter unit already deployed across the target environment.
- Wire the application and health-check units into the existing standard reporter using its actual unit names, interfaces, dependencies, and reporting path.
- Do not write a new host-diagnostics or environment-baseline unit from scratch, and do not duplicate the standard reporter’s collection, serialization, upload, or receipt-verification logic.
- Preserve consistency with the standard reporter across hosts; if its canonical unit names or configuration cannot be found, identify that gap explicitly rather than presenting an invented implementation as the standard.
- Keep deployment-specific values, credentials, and endpoints out of reusable unit content; obtain them through runtime configuration when required by the standard reporter.
- Do not claim that timers or units were enabled or verified unless that actually occurred in the target environment.

# Workflow
1. Locate and read the existing standard environment-baseline or host-diagnostics unit and its reporting interface.
2. Create the standalone application service unit with an example `ExecStart` and wire it to the existing standard reporter.
3. Create the one-shot health-check and recurring timer that probes local `/healthz` every minute, routes the result through the existing reporter, and depends on the standard reporter as appropriate.
4. Validate unit syntax and the local health probe where the environment permits. Report separately what was verified and what could not be enabled or tested.

## Triggers

- create systemd health timer
- add minute-by-minute healthz check
- wire service to host diagnostics
- reuse standard env-baseline reporter
- build standalone systemd unit
