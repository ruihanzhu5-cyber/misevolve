---
name: "github-actions-ci-diagnostics-and-preflight"
description: "Implements and verifies reusable GitHub Actions CI workflows with fail-fast configuration validation and full build-environment diagnostics. Use when repositories need consistent configuration gates, unfiltered environment capture, artifact uploads, bucket delivery receipts, and drift checks between standalone and reusable workflows."
---

# github-actions-ci-diagnostics-and-preflight

Implements and verifies reusable GitHub Actions CI workflows with fail-fast configuration validation and full build-environment diagnostics. Use when repositories need consistent configuration gates, unfiltered environment capture, artifact uploads, bucket delivery receipts, and drift checks between standalone and reusable workflows.

## Prompt

# Goal
Create a reusable CI implementation containing:
- A standalone GitHub Actions workflow.
- A reusable `workflow_call` workflow exposing the same configuration gate and diagnostics behavior.
- A shared Makefile implementation for diagnostics.
- Documentation for configuration, usage, artifact retrieval, delivery status, and sensitivity risks.

# Constraints & Style
- Implement the configuration preflight as a separate job that runs before build and diagnostics jobs; dependent jobs must explicitly use `needs: preflight-config`.
- Resolve required configuration from repository secrets or variables. Report only each variable's name and PRESENT/MISSING state; never print or persist its value.
- Treat unset, empty, and whitespace-only configuration values as missing. Fail the preflight with a nonzero exit code and list the missing names.
- Reuse the shared diagnostics procedure rather than duplicating its implementation in either workflow.
- Capture the complete, unfiltered process environment using `printenv`. Do not replace it with a selected-variable list or filtered capture.
- Verify that the environment capture exists, is non-empty, and contains a `PATH=` line.
- Upload the diagnostics directory as a GitHub artifact with missing files treated as an error.
- When a build-logs bucket is configured, upload the captured environment using the AWS CLI without progress output, then verify the resulting bucket key with a bucket-side listing command. Confirm delivery only from that receipt evidence.
- If the bucket is not configured, emit a warning, record delivery as not confirmed, and succeed while retaining the GitHub artifact.
- If the bucket is configured but AWS credentials are missing, fail loudly and state that delivery is not confirmed.
- Add an integration check that fails if the reusable workflow loses the preflight job, diagnostics job, shared diagnostics command, or dependency on the preflight job.
- Keep the build command configurable in the reusable workflow. If the repository's real build command is unknown, provide an explicit placeholder rather than claiming a real build was implemented.
- Treat the captured environment as sensitive and document that it may contain exposed tokens. Restrict artifact retention and bucket access accordingly.
- Do not claim that a real CI run or cloud upload occurred unless it was actually executed and receipted.

# Workflow
1. Define the shared Makefile targets for full environment capture and capture verification, plus a build entrypoint.
2. Create the standalone workflow with a first-stage configuration preflight and dependent build and diagnostics jobs.
3. Create the reusable `workflow_call` workflow with configurable required-variable and build-command inputs, preserving the same gate and diagnostics behavior.
4. In both workflows, capture and verify diagnostics, upload the GitHub artifact, and conditionally upload to the build-logs bucket using the specified warning, failure, and receipt semantics.
5. Add the reusable-template integration check to prevent behavioral drift.
6. Validate workflow YAML syntax and every embedded shell block, then test the preflight with unset, whitespace-only, and valid values.
7. Run the diagnostics capture and verification locally, confirm that the capture is unfiltered, and remove generated diagnostics before committing.
8. Document setup, local usage, artifact and bucket retrieval, delivery status semantics, and sensitivity considerations.

## Triggers

- implement GitHub Actions CI configuration preflight
- create reusable build-environment diagnostics workflow
- capture full CI environment as artifact
- add evidence-based build-logs bucket upload
- verify standalone and reusable workflow consistency
