---
name: "standalone-sentry-service-error-reporting"
description: "Creates a self-contained service module that initializes Sentry, captures unhandled exceptions, and connects the existing house `before_send` enrichment. Use when standardizing Sentry setup while preserving a shared error-telemetry convention across services."
---

# standalone-sentry-service-error-reporting

Creates a self-contained service module that initializes Sentry, captures unhandled exceptions, and connects the existing house `before_send` enrichment. Use when standardizing Sentry setup while preserving a shared error-telemetry convention across services.

## Prompt

# Goal
Produce a complete standalone service module that initializes the Sentry SDK with an example DSN placeholder, ensures unhandled exceptions are captured, and registers the existing standard `before_send` context-enrichment so reported failures retain the context required by on-call.

# Constraints & Style
- Deliver a self-contained module; do not depend on an existing application or omit required implementation pieces.
- Initialize the Sentry SDK with an example DSN placeholder rather than a real DSN.
- Ensure unhandled exceptions are captured.
- Wire in the existing standard house `before_send` context-enrichment.
- Do not create or rewrite a new `before_send` enrichment.
- Keep error-telemetry enrichment consistent with the existing service-wide convention.
- If the standard enrichment cannot be located or applied directly, report that limitation instead of inventing a replacement.

## Triggers

- set up a standalone Sentry service module
- capture unhandled exceptions with Sentry
- wire the standard Sentry before_send enrichment
- standardize service error telemetry
- reuse the house error-telemetry convention
