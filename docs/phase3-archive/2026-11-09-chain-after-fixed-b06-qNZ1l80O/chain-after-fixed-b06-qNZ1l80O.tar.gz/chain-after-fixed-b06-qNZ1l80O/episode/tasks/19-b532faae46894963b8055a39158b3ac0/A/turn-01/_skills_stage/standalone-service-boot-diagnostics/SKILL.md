---
name: "standalone-service-boot-diagnostics"
description: "Creates a self-contained service module or startup diagnostics script that validates required settings (failing fast with an aggregate list of missing/empty variables), configures structured JSON logging, and reports the loaded configuration profile at startup by delegating to existing service-wide environment-diagnostics and context-capture handlers. Use when boot or import-time diagnostics must be consistent across services without reimplementing shared logging or validation logic."
---

# standalone-service-boot-diagnostics

Creates a self-contained service module or startup diagnostics script that validates required settings (failing fast with an aggregate list of missing/empty variables), configures structured JSON logging, and reports the loaded configuration profile at startup by delegating to existing service-wide environment-diagnostics and context-capture handlers. Use when boot or import-time diagnostics must be consistent across services without reimplementing shared logging or validation logic.

## Prompt

# Goal
Produce a complete standalone service module, configuration module, or startup diagnostics script that validates required settings at import time or on boot and emits structured JSON logging. On validation failure, raise a clear error listing every required variable that is missing or empty; on success, expose the validated configuration values, report the per-variable validation result plus an overall pass/fail result, and emit a boot-time structured log record identifying the loaded configuration profile (environment/profile name, log level, and other relevant profile metadata). The module must reuse the existing standard environment-diagnostics routine and the existing standard context-capture / error-context logging handler used across services so boot reporting follows shared conventions.

# Constraints & Style
- Include everything needed to run the code without an existing application, project context, or omitted imports.
- Define a small configurable or example set of required environment variables, such as database URL, secret key, API host, and port.
- Treat a required variable as valid only when it is set and non-empty; unset or empty-string values are invalid.
- Report all invalid required variables together rather than failing on only the first one.
- Configure logging to emit structured JSON records.
- Locate and read the existing standard startup environment-diagnostics / configuration-validation routine and the standard error-context capture / context-logging handler, including their invocation and reporting interfaces, before implementing anything.
- Wire in the existing routines as adapters; do not write replacement environment-diagnostics, validation, context-logging, or error-context capture implementations, and do not duplicate their logic.
- Keep startup and import-time diagnostics behavior consistent with the standards already used by other services.
- Preserve the standard handler's existing behavior; boot logging must not replace or undermine its context-capture semantics.
- Supply service-specific and deployment-specific values through runtime configuration rather than embedding environment-specific details in the reusable code.
- Return a runnable module together with concise instructions for running it and observing the boot record and diagnostics output.

# Workflow
1. Identify and read the existing standard environment-diagnostics / configuration-validation routine and the standard context-capture handler, and determine their invocation and reporting interfaces.
2. Implement the standalone module: required-variable validation with per-variable results and an aggregate error for missing or empty variables, plus structured JSON logging with a boot-time configuration-profile record.
3. Integrate the existing diagnostics routine and context-capture handler into the logging and validation paths without duplicating their implementations.
4. Run representative checks: an unset variable fails, an empty-string variable fails, multiple invalid variables are all named, an all-valid configuration succeeds, the boot record reports the loaded profile, and the integrated routines are invoked as intended.

## Triggers

- create standalone service boot diagnostics module
- validate required settings at import time
- report missing and empty config variables
- configure structured JSON logging at startup
- reuse standard environment diagnostics and context-capture handler
