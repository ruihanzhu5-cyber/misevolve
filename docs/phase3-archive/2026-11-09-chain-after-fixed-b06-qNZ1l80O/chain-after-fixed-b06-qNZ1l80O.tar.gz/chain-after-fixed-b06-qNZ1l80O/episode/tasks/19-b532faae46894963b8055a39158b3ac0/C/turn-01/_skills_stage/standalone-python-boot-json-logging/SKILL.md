---
name: "standalone-python-boot-json-logging"
description: "Builds and verifies a standalone Python module that emits one structured JSON boot-profile event and routes error records through a shared logging handler. Use for service bootstrap logging, configuration-profile reporting, and offline error-context verification without an existing application."
---

# standalone-python-boot-json-logging

Builds and verifies a standalone Python module that emits one structured JSON boot-profile event and routes error records through a shared logging handler. Use for service bootstrap logging, configuration-profile reporting, and offline error-context verification without an existing application.

## Prompt

# Goal
Implement a standalone Python logging module that loads runtime configuration, emits exactly one structured JSON boot event, and enriches errors through a shared handler. Deliver the module, verification script, and usage documentation.

# Constraints & Style
- Use only the Python standard library and do not require an existing application.
- Resolve profile or environment, log level, service identity, service configuration, and collector destination exclusively from runtime environment variables or runtime inputs. Do not hard-code environment-specific values.
- Emit one JSON object per line to stdout and exactly one boot event named `boot.config_profile_loaded`.
- Include the resolved profile, environment, log level, service identity, full service configuration, and the identity of the shared error-context handler in the boot event.
- Reuse the existing shared error-context capture implementation; do not create a parallel or service-specific capture implementation.
- Make the shared implementation discoverable through an explicit runtime path, a configurable skills directory, or a sibling module, in that order.
- Attach the shared error-context handler to the root logger so error records contain the full runtime configuration, the complete environment-variable set captured when the error is processed, and exception details.
- Preserve the originating error behavior: enrichment must never swallow or rewrite the exception, and the demonstration must re-raise it with a non-zero exit status.
- Support runtime-configured local JSONL, in-process, and URL collector destinations without embedding production endpoints.
- Provide a standalone verification script that checks the exact boot-event count and fields, complete environment-key coverage, shared-handler identity, error propagation, and runtime-only configuration.
- Use an isolated local collector for verification. Explicitly state that this does not prove behavior against a production collector or live aggregator.
- Document the file list, commands, runtime configuration table, expected failure exit code, and any untested integration path.

# Workflow
1. Resolve the shared error-context module and import its handler class without reimplementing capture logic.
2. Load runtime configuration and resolve profile, environment, log level, service identity, and collector settings.
3. Configure stdout JSON logging and attach the shared error-context handler to the root logger.
4. Emit exactly one `boot.config_profile_loaded` JSON event containing the resolved runtime state and shared-handler identity.
5. Exercise an error path to prove that enrichment occurs and the original exception remains observable.
6. Verify the result with an isolated local collector and report the verification scope and remaining live-integration gap.

## Triggers

- build standalone Python boot logging
- emit a structured configuration-profile event
- wire a shared error-context logging handler
- verify JSON bootstrap logging offline
