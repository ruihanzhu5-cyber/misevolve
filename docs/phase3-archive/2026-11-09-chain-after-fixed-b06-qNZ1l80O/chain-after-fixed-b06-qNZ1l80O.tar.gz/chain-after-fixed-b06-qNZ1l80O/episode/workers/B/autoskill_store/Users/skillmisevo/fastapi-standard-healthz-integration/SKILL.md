---
id: "0e2429c7-3b45-525c-84ce-c3a1062ead65"
name: "fastapi-standard-healthz-integration"
description: "Creates standalone FastAPI services with a load-balancer-facing `/healthz` endpoint that uses the established shared diagnostics reporter to report configuration-loading status consistently."
version: "0.1.0"
tags:
  - "FastAPI"
  - "healthz"
  - "diagnostics"
  - "liveness"
  - "Python"
triggers:
  - "create standalone FastAPI healthz endpoint"
  - "add FastAPI liveness endpoint"
  - "report config load status"
  - "integrate standard health diagnostics"
  - "build FastAPI app.py"
---

# fastapi-standard-healthz-integration

Creates standalone FastAPI services with a load-balancer-facing `/healthz` endpoint that uses the established shared diagnostics reporter to report configuration-loading status consistently.

## Prompt

# Goal
Create a complete standalone FastAPI module named `app.py`, including all required code, with a `/healthz` endpoint that returns HTTP 200 and a small JSON body reporting whether configuration loaded correctly.

# Constraints & Style
- Do not depend on an existing application or omitted project context; include everything needed in `app.py`.
- Use the established house health/config-report convention and the existing standard diagnostics reporter or routine.
- Do not create a new, parallel health or diagnostics reporter from scratch; wire the service into the existing standard implementation so reporting remains consistent across services.
- The `/healthz` response must be compact JSON and clearly indicate whether configuration loaded successfully.
- Keep the endpoint suitable for load-balancer liveness checks: it must return HTTP 200 as requested.
- Resolve environment-specific configuration through runtime inputs or configuration rather than hard-coding deployment values.
- Keep secrets and environment-specific values out of source code.
- Ensure configuration-loading failures are reported clearly without preventing the service from exposing the requested health response.

## Triggers

- create standalone FastAPI healthz endpoint
- add FastAPI liveness endpoint
- report config load status
- integrate standard health diagnostics
- build FastAPI app.py
