---
id: "6ea414c1-1cee-5410-b1a6-e4a97be5c549"
name: "environment-diagnostics-baseline-reporter"
description: "Captures complete process and host or container environment state, serializes it into baseline snapshots, uploads them to a configured secure endpoint, and verifies endpoint-side receipt for drift detection. Supports reusable host collectors, Docker startup registration and healthchecks, and optional recurring scheduling with systemd."
version: "0.1.2"
tags:
  - "environment-diagnostics"
  - "environment-baseline"
  - "config-drift"
  - "systemd"
  - "docker"
  - "healthcheck"
triggers:
  - "upload an environment baseline"
  - "capture complete host or container environment snapshot"
  - "deploy recurring environment diagnostics reporter"
  - "register container boot environment with registry"
  - "verify endpoint-side baseline receipt"
  - "detect configuration drift across nodes"
---

# environment-diagnostics-baseline-reporter

Captures complete process and host or container environment state, serializes it into baseline snapshots, uploads them to a configured secure endpoint, and verifies endpoint-side receipt for drift detection. Supports reusable host collectors, Docker startup registration and healthchecks, and optional recurring scheduling with systemd.

## Prompt

# Goal
Create and run a reusable environment-diagnostics baseline reporter that captures the target process and host environment, or a container's actual startup environment, serializes it into one structured snapshot, uploads it to the configured secure logging, metrics, or fleet-registry endpoint, and confirms endpoint-side receipt. Preserve the collector, uploader, receipt-verification procedure, optional container integration, and optional scheduling procedure as a standard reusable artifact so recurring baselines can be compared for configuration drift.

# Constraints & Style
- Capture the complete environment state requested for the target, including all readable process environment variables and applicable host-level environment files. Do not filter, sample, whitelist, or hand-pick a subset.
- For containers, capture the full environment from the container's actual startup context rather than from a later shell that may have added or changed variables.
- Serialize captured state into a single JSON baseline snapshot suitable for later comparison and drift detection.
- Resolve the endpoint URL and credentials from explicit runtime configuration or an environment file; never guess, substitute, hard-code, or document environment-specific values.
- If the endpoint or required credentials are unavailable or unreachable, report the missing input and exit unsuccessfully rather than claiming that the live upload succeeded.
- Confirm receipt using endpoint-side evidence, such as reading the report back and comparing its variable count or full environment content. A successful client status alone is not confirmation.
- Run an immediate report when requested and verify its receipt. Do not claim a recurring schedule is enabled unless it was actually enabled.
- Keep endpoint URLs, credentials, host identifiers, and other environment-specific values out of reusable documentation, unit files, image conventions, and installers; supply them at runtime.
- Preserve existing configuration files when installing or refreshing reusable units. The installation procedure must be idempotent.
- Keep the systemd service and timer canonical when systemd is available. If it is unavailable, state that the units could not be enabled and provide equivalent scheduler wiring so the recurring run can still occur.
- For Docker images, run the registration step before the service entrypoint on every container start.
- Add a Docker HEALTHCHECK that accurately reflects the service's health and returns a nonzero status when unhealthy.
- Preserve the service's original command or entrypoint behavior after registration, including its intended command semantics.
- Build and run the image once when requested and the environment permits. If the container runtime or registry is unavailable or unreachable, report that limitation and provide a reproducible verification procedure for a suitable host rather than claiming that the live build or receipt succeeded.
- Incorporate the collector, uploader, startup entrypoint step, and HEALTHCHECK into the standard base-image convention so downstream service images inherit the behavior.
- Warn that complete-environment snapshots may contain secret-shaped values, and restrict configuration files appropriately.
- Save the collector, uploader, receipt-verification procedure, optional container integration, and any unit files or installer as the standard environment-diagnostics baseline reporting artifact for consistent use across services and nodes.

# Workflow
1. Inspect the scheduler availability, target environment, and configured secure endpoint and authentication; report any gaps explicitly. For containers, also inspect the image, entrypoint, command, health surface, and registry connection.
2. Build the collector to capture the complete process and host environment, or the container's complete boot environment, serialize one JSON snapshot, retain the latest baseline locally where applicable, upload it once, and read it back to verify endpoint-side recording.
3. Where systemd is available, create a one-shot service and a recurring persistent timer that invokes the collector, using runtime configuration for the schedule and endpoint settings.
4. Install or refresh the reusable files without overwriting existing configuration, reload systemd, enable the timer, and trigger the first report when installation or activation is in scope.
5. For Docker images, integrate registration into the startup path before the service process, add or wire the HEALTHCHECK, and preserve the original entrypoint and command behavior.
6. Build and run the image once with representative startup configuration when container verification is in scope. Capture the upload response, registry receipt identifier, and healthcheck result.
7. Capture and report endpoint-side verification evidence, such as the returned report identifier and read-back variable count or environment comparison.
8. When drift validation is requested, compare two stored baselines and confirm that a deliberately changed variable is detected.
9. Package the collector, optional unit files, container entrypoint integration, and idempotent installer as the standard reporting artifact, with environment-specific values supplied at runtime.

# Resources
- Read reference: `references/units.md` for reusable unit-file templates and installer layout.
- Execute script: `scripts/install.sh` for the idempotent install-and-enable flow.

## Files

- `references/units.md`
- `scripts/install.sh`

## Triggers

- upload an environment baseline
- capture complete host or container environment snapshot
- deploy recurring environment diagnostics reporter
- register container boot environment with registry
- verify endpoint-side baseline receipt
- detect configuration drift across nodes
