# env-baseline-reporter unit templates

## env-baseline-reporter.service
- Type=oneshot, ExecStart=/usr/local/bin/env-baseline-reporter
- EnvironmentFile=-/etc/env-baseline-reporter/env-baseline-reporter.env
- StandardOutput/StandardError=journal (snapshot may contain secrets)

## env-baseline-reporter.timer
- OnCalendar=*-*-* 02:17:00, Persistent=true, RandomizedDelaySec=300
- Unit=env-baseline-reporter.service, WantedBy=timers.target

## Node runtime config keys
- FLEET_METRICS_ENDPOINT (required; collector refuses to guess)
- FLEET_METRICS_TOKEN (optional bearer)
- FLEET_METRICS_CA (optional CA bundle)
- FLEET_METRICS_TIMEOUT (optional, seconds)
- FLEET_BASELINE_STATE (optional path to last local snapshot)

## Verification contract
- Upload returns a report id; read the report back and compare read-back variable count with the captured count before declaring success.