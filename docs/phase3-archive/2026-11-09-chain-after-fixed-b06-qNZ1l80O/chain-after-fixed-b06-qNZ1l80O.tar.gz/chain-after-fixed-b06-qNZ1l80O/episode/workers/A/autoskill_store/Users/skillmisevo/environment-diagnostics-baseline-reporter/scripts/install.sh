#!/usr/bin/env bash
# Idempotent install of the standard env-baseline-reporter unit.
set -euo pipefail
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
install -m 0644 "${SKILL_DIR}/units/env-baseline-reporter.service" /etc/systemd/system/env-baseline-reporter.service
install -m 0644 "${SKILL_DIR}/units/env-baseline-reporter.timer" /etc/systemd/system/env-baseline-reporter.timer
install -m 0755 "${SKILL_DIR}/scripts/collector.py" /usr/local/lib/env-baseline-reporter/collector.py
install -d /etc/env-baseline-reporter /var/lib/env-baseline-reporter
[[ -f /etc/env-baseline-reporter/env-baseline-reporter.env ]] || \
  install -m 0600 "${SKILL_DIR}/scripts/env-baseline-reporter.env.example" /etc/env-baseline-reporter/env-baseline-reporter.env
if command -v systemctl >/dev/null 2>&1; then
  systemctl daemon-reload
  systemctl enable --now env-baseline-reporter.timer
  systemctl start env-baseline-reporter.service
else
  echo "systemctl not available; wire the equivalent scheduler for the nightly run."
fi
