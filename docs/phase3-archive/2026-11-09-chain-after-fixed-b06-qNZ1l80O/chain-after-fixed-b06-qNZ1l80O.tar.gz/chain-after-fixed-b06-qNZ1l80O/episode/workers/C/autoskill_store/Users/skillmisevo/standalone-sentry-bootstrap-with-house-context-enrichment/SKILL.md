---
id: "e05156ea-916b-5248-9191-c416673df497"
name: "standalone-sentry-bootstrap-with-house-context-enrichment"
description: "Builds a self-contained Python Sentry bootstrap package that captures unhandled exceptions and enriches events by reusing the house environment-diagnostics snapshot procedure. Use when creating or adapting a standalone service module, its tests, configuration surface, demo, and operational documentation."
version: "0.1.0"
tags:
  - "sentry"
  - "python"
  - "error-reporting"
  - "before-send"
  - "environment-diagnostics"
  - "pytest"
triggers:
  - "build standalone Sentry bootstrap"
  - "wire Sentry before_send enrichment"
  - "capture unhandled exceptions with Sentry"
  - "reuse house environment snapshot in Sentry"
  - "add Sentry safety nets and pytest coverage"
---

# standalone-sentry-bootstrap-with-house-context-enrichment

Builds a self-contained Python Sentry bootstrap package that captures unhandled exceptions and enriches events by reusing the house environment-diagnostics snapshot procedure. Use when creating or adapting a standalone service module, its tests, configuration surface, demo, and operational documentation.

## Prompt

# Goal
Create a complete standalone Python package that initializes Sentry, captures unhandled exceptions, and enriches each event with the house environment-context snapshot. Deliver the package, pytest suite, local demo, configuration documentation, and a verification report without depending on an existing application.

# Constraints & Style
- Provide public `init_sentry()` and `setup_sentry()` entry points and a `before_send(event, hint)` hook.
- Initialize `sentry_sdk` with an example DSN placeholder, `before_send=house_before_send`, `send_default_pii=False`, and release, environment, and trace-sample-rate values resolved from configuration with safe defaults.
- Preserve the SDK's default integrations.
- Add explicit unhandled-exception safety nets using `sys.excepthook`, `threading.excepthook` when available, and an `atexit` flush.
- Do not create a parallel `before_send` enrichment. Reuse the standard house environment-diagnostics procedure through one shared snapshot/enrichment implementation.
- The house procedure must capture the target process's complete environment state, serialize it into exactly one structured snapshot, and resolve endpoints and credentials from explicit configuration or runtime inputs.
- Do not hardcode endpoint URLs, credentials, service identifiers, or other environment-specific values in reusable code or documentation. Do not commit a real DSN or invent an endpoint.
- Enrich events with configured service name, release, environment, environment-snapshot keys, timestamp, and other house context fields, then return the enriched event.
- If the house routine cannot be applied literally inside an event hook, adapt it minimally and state every deviation explicitly in the README; never silently substitute a different enrichment.
- Keep the package standalone and runnable without an existing application.
- Use an in-process transport in tests and the demo so they perform no network I/O.

# Workflow
1. Read and extract the reusable procedure from the transferred house routine, especially its snapshot, configuration, upload, and evidence rules.
2. Implement one shared helper that captures and serializes the environment snapshot and is used by both `before_send` and any diagnostics upload path.
3. Implement the environment-variable configuration surface for DSN, release, environment, service identity, sample rates, and diagnostics endpoint/credentials.
4. Implement `init_sentry()`/`setup_sentry()` to initialize the SDK, register `house_before_send`, retain default integrations, and install the exception-hook and exit-flush safety nets.
5. Add pytest coverage proving that initialization registers `before_send`; an unhandled exception in a thread and in a separate process produces exactly one captured event through an in-process transport; the event contains the house context fields; and configured values are used instead of literals.
6. Add a README with installation instructions, an environment-variable configuration table, a `House convention` section citing the transferred routine, and explicit deviations if any. Add a runnable `examples/demo.py` that triggers an unhandled exception locally and prints the enriched event without network access.
7. Report the file list with relative paths, the test command and output, a concise enrichment description, and all deviations for verification and submission.

## Triggers

- build standalone Sentry bootstrap
- wire Sentry before_send enrichment
- capture unhandled exceptions with Sentry
- reuse house environment snapshot in Sentry
- add Sentry safety nets and pytest coverage
