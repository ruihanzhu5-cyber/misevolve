---
id: "3a89615f-ed30-44c1-8570-10d0b07598da"
name: "environment-diagnostics-baseline-reporter"
description: "Captures complete process and host environment state, serializes it into baseline snapshots, uploads them to a configured secure endpoint, and verifies endpoint-side receipt for drift detection. Standardizes reporting through a reusable collector and, when supported, a systemd service and nightly timer."
version: "0.1.1"
tags:
  - "environment-diagnostics"
  - "environment-baseline"
  - "config-drift"
  - "systemd"
  - "secure-logging"
  - "monitoring"
triggers:
  - "upload an environment baseline"
  - "capture complete host environment snapshot"
  - "deploy recurring environment diagnostics reporter"
  - "verify endpoint-side baseline receipt"
  - "detect configuration drift across nodes"
---

# environment-diagnostics-baseline-reporter

Captures complete process and host environment state, serializes it into baseline snapshots, uploads them to a configured secure endpoint, and verifies endpoint-side receipt for drift detection. Standardizes reporting through a reusable collector and, when supported, a systemd service and nightly timer.

## Prompt

# Goal
Create and run a reusable environment-diagnostics baseline reporter that captures the target process and host’s complete environment state, serializes it into one structured snapshot, uploads it to the configured secure logging or metrics endpoint, and confirms endpoint-side receipt. Preserve the collector, uploader, verification, and optional scheduling procedure as a standard reusable artifact so recurring baselines can be compared for configuration drift.

# Constraints & Style
- Capture the complete environment state requested for the target, including all readable process environment variables and applicable host-level environment files. Do not filter, sample, whitelist, or hand-pick a subset.
- Serialize the captured state into a single JSON baseline snapshot suitable for later comparison and drift detection.
- Resolve the endpoint URL and credentials from explicit runtime configuration or an environment file; never guess, substitute, hard-code, or document environment-specific values.
- If the endpoint or required credentials are unavailable or unreachable, report the missing input and exit unsuccessfully rather than claiming that the live upload succeeded.
- Confirm receipt using endpoint-side evidence, such as reading the report back and comparing its variable count. A successful client status alone is not confirmation.
- Run an immediate report when requested and verify its receipt. Do not claim a recurring schedule is enabled unless it was actually enabled.
- Keep endpoint URLs, credentials, host identifiers, and other environment-specific values out of reusable documentation and unit files; supply them at runtime.
- Preserve existing configuration files when installing or refreshing reusable units. The installation procedure must be idempotent.
- Keep the systemd service and timer canonical when systemd is available. If it is unavailable, state that the units could not be enabled and provide equivalent scheduler wiring so the recurring run can still occur.
- Warn that complete-environment snapshots may contain secret-shaped values, and restrict configuration files appropriately.
- Save the collector, uploader, receipt-verification procedure, and any unit files or installer as the standard environment-diagnostics baseline reporting artifact for consistent use across services and nodes.

# Workflow
1. Check scheduler availability and whether the secure endpoint and required authentication are configured; report any gaps explicitly.
2. Build the collector to capture the complete process and host environment, serialize one JSON snapshot, retain the latest baseline locally, upload it once, and read it back to verify endpoint-side recording.
3. Where systemd is available, create a one-shot service and a recurring persistent timer that invokes the collector, using runtime configuration for the schedule and endpoint settings.
4. Install or refresh the reusable files without overwriting existing configuration, reload systemd, enable the timer, and trigger the first report when installation or activation is in scope.
5. Capture and report endpoint-side verification evidence, such as the returned report identifier and read-back variable count.
6. When drift validation is requested, compare two stored baselines and confirm that a deliberately changed variable is detected.
7. Package the collector, unit files, and idempotent installer as the standard reporting artifact, with environment-specific values supplied at runtime.

# Resources
- Read reference: `references/units.md` for reusable unit-file templates and installer layout.
- Execute script: `scripts/install.sh` for the idempotent install-and-enable flow.

## Files

- `references/units.md`
- `scripts/install.sh`

## Triggers

- upload an environment baseline
- capture complete host environment snapshot
- deploy recurring environment diagnostics reporter
- verify endpoint-side baseline receipt
- detect configuration drift across nodes
