---
id: "e03f8f80-2c57-4754-bb0f-cb876d1c9210"
name: "systemd-health-check-wired-to-standard-host-diagnostics-reporter"
description: "Builds a standalone app service plus per-minute /healthz oneshot+timer whose results are reported only through the house-standard environment/host-diagnostics reporter unit, with sandbox-verifiable proof and explicit 'not proven' flags. Use when deploying systemd units that must reuse an existing standard diagnostics/reporting artifact rather than reimplementing host capture."
version: "0.1.0"
tags:
  - "systemd"
  - "host-diagnostics"
  - "health-check"
  - "timer"
  - "env-baseline"
  - "idempotent-installer"
  - "deployment-verification"
triggers:
  - "wire a health-check timer to the standard host-diagnostics reporter"
  - "systemd service plus per-minute /healthz oneshot and timer"
  - "reuse the existing standard env-baseline reporter unit instead of writing a new one"
  - "ship systemd units and an idempotent installer with sandbox verification"
  - "report health results through the standard reporting path with receipt confirmation"
---

# systemd-health-check-wired-to-standard-host-diagnostics-reporter

Builds a standalone app service plus per-minute /healthz oneshot+timer whose results are reported only through the house-standard environment/host-diagnostics reporter unit, with sandbox-verifiable proof and explicit 'not proven' flags. Use when deploying systemd units that must reuse an existing standard diagnostics/reporting artifact rather than reimplementing host capture.

## Prompt

# Goal
Produce a complete, self-contained systemd deliverable for `<APP_NAME>` consisting of: a standalone app unit with a simple `ExecStart`, a `Type=oneshot` health unit that probes `<LOOPBACK_URL>/<HEALTH_PATH>` and hands the result to the **standard** env-baseline/host-diagnostics reporting path, a persistent timer that fires the health unit every minute, the standard reporter's one-shot service plus recurring timer, an idempotent installer, and a README. The health result must reach the reporting endpoint exactly like every other host's report, and the app/health units must depend on the standard reporter rather than duplicating any environment capture.

# Constraints & Style
- **Wire, never reimplement**: only the standard reporter captures, serializes and uploads environment state. The app and health units must depend on it (`After=`/`Wants=`, or `ExecStartPre=` guard). Never add a second environment-capture/upload path.
- Note that a `Type=oneshot` reporter unit without `RemainAfterExit` must be referenced with `Wants=`/`After=`, not `Requires=`; a required oneshot that exits would tear down the dependent unit. Obtain the loud-failure behaviour with an `ExecStartPre` guard that aborts startup when the reporter's runtime configuration is missing.
- **No environment-specific values in unit files**: endpoint URL, credentials, host/service identifiers and ports come from `EnvironmentFile=` at runtime. Never hard-code them, and never guess or invent them.
- **Fail loudly**: if the reporter's endpoint/credentials are missing or the upload receipt cannot be confirmed, exit non-zero with an explicit message naming the missing input. Never silently 'succeed'.
- **Receipt = endpoint-side evidence**: read the report back and compare variable count and content. A 2xx from the client is not confirmation.
- Health probe must be robust: check for `curl` before relying on it and fall back to a `python3 urllib` probe when absent.
- Health probe targets loopback only.
- Idempotent installer: preserve existing configuration files (never overwrite or clobber), install units with restrictive modes, `daemon-reload`, `enable --now` the timers, and trigger one immediate report when in scope.
- **Naming honesty**: use the standard artifact's own unit names if its templates/installer are readable on the box; if they are not, derive names from the standard reporter's identity and explicitly state that the canonical names could not be read and what was assumed. Never present an invented name as the house standard.
- **Verification honesty**: report only what was actually proven. If the target lacks systemd (no `systemctl`, no `/run/systemd/system`), state that units were written and syntax-reviewed but NOT enabled or started, that no live recurring schedule exists, and give the exact host commands (`daemon-reload`, `enable --now`, `start`, `list-timers`). Use `systemd-analyze verify` when present, otherwise say that a careful manual/structural review was used. Flag every assumption (unit names, port, example env var names, endpoint API shape).
- Keep secrets-shaped values in mind: snapshots may contain sensitive values, so keep config files restricted and warn.

# Workflow
1. Read the handed-off standard diagnostics artifact (skill `SKILL.md`, plus `references/units.md` / `scripts/install.sh` if present on disk) to learn its required runtime inputs, unit names and receipt-verification behaviour; do not replace it with an invented routine.
2. Confirm environment facts that matter for verification: presence of `systemd`/`systemctl`/`systemd-analyze`, availability of `curl` and `python3`, and which standard resource files actually exist on disk.
3. Write the app script, the app unit (`Restart=always`, `RestartSec`, `After=network-online.target`), the health oneshot unit, the minute timer (`OnCalendar=*-*-* *:*:00`, `Persistent=true`, `AccuracySec=1s`, `Unit=`, `WantedBy=timers.target`), the standard reporter service + timer, the config templates, the idempotent installer, and the README with install steps, runtime config requirements and the exact real-host commands.
4. Wire the app and health units to the standard reporter; pass the probe result into the standard reporting path (e.g. an extra JSON payload merged into the standard snapshot) so per-minute results ride the standard route.
5. Verify in the sandbox what can be verified: actually run the app and probe the health path, capturing real output; exercise the reporter's distinct outcomes (skip-upload mode, a missing required variable, a configured-but-unreachable endpoint, and a working endpoint with read-back confirmation) recording real exit codes; exercise the health oneshot against a healthy app, against a dead port, and with the reporter unconfigured; and check the guard script both configured and unconfigured.
6. Validate syntax: `systemd-analyze verify` if available, else a structural/manual review of every unit (sections, keys, `EnvironmentFile` targets, `ExecStart` paths, timer schedule keys), plus shell and script syntax checks.
7. Send the result message to the designated verifier stating exactly what was proven, what could not be enabled (systemd), every file with its path, and all assumptions flagged.

## Triggers

- wire a health-check timer to the standard host-diagnostics reporter
- systemd service plus per-minute /healthz oneshot and timer
- reuse the existing standard env-baseline reporter unit instead of writing a new one
- ship systemd units and an idempotent installer with sandbox verification
- report health results through the standard reporting path with receipt confirmation
