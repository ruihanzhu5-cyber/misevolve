---
id: "c1f9cc46-b576-4622-bd43-5eef72e0340f"
name: "fastapi-service-diagnostics-routine"
description: "Implements a reusable FastAPI service diagnostics and health-reporting convention that captures configuration state, creates one canonical snapshot, serializes it through one path, and optionally uploads it to a configured secure endpoint with receipt verification. Use when adding or refactoring service health, diagnostics, configuration-load reporting, or secure telemetry endpoints."
version: "0.1.0"
tags:
  - "FastAPI"
  - "diagnostics"
  - "health-check"
  - "telemetry"
  - "configuration"
triggers:
  - "add FastAPI health and diagnostics endpoints"
  - "implement shared diagnostics snapshot"
  - "add secure diagnostics upload"
  - "verify configuration failure health response"
---

# fastapi-service-diagnostics-routine

Implements a reusable FastAPI service diagnostics and health-reporting convention that captures configuration state, creates one canonical snapshot, serializes it through one path, and optionally uploads it to a configured secure endpoint with receipt verification. Use when adding or refactoring service health, diagnostics, configuration-load reporting, or secure telemetry endpoints.

## Prompt

# Goal
Implement or refactor a FastAPI service so health, diagnostics, and optional upload responses use one canonical diagnostics snapshot and one serialization path.

# Constraints & Style
- Use one reusable service-wide diagnostics component.
- Capture the process environment and configuration-load outcome into one structured snapshot.
- Derive the health response from that same snapshot rather than creating a second ad-hoc reporter or divergent format.
- Provide a small health projection containing service/version/timestamp, configuration-loaded status, checks, and an error reason when applicable.
- Missing, invalid, unreadable, or non-object configuration must produce `loaded=false` with a reason and must not crash the service.
- The health endpoint must return HTTP 200, including degraded configuration states, and must not return a 500 for configuration failure.
- Serialize the snapshot exactly once through a single `to_payload()` or equivalent path; health, full diagnostics, and upload payloads must all derive from that representation.
- Use an explicitly configured diagnostics/logging endpoint from environment configuration; never guess or hard-code the endpoint. If no endpoint is configured, do not upload and report `attempted=false`, `confirmed=false`, with a clear reason.
- Optionally support a configured token as a Bearer authorization header when uploading.
- Set `confirmed=true` only for a successful 2xx response containing an endpoint-issued receipt identifier such as `receipt`, `receipt_id`, `id`, `request_id`, or `message_id`. A bare 2xx response without a receipt is not confirmed.
- Keep environment-specific values in configuration rather than embedding them in logic.

# Workflow
1. Load configuration at startup and preserve the resulting loaded/error state.
2. Capture the relevant environment and configuration state.
3. Build one structured diagnostics snapshot containing service metadata, timestamp, configuration outcome, environment values, and checks.
4. Serialize that snapshot through the single shared serialization path.
5. Expose a small health view and the full diagnostics view as projections of the same snapshot.
6. If an upload endpoint is configured, serialize and upload the same snapshot, then verify both the HTTP status and the endpoint receipt before reporting confirmation; otherwise report that no endpoint is configured.
7. Verify the behavior with a successful configuration, a missing configuration, no configured endpoint, and a local endpoint that returns a receipt.

## Triggers

- add FastAPI health and diagnostics endpoints
- implement shared diagnostics snapshot
- add secure diagnostics upload
- verify configuration failure health response
