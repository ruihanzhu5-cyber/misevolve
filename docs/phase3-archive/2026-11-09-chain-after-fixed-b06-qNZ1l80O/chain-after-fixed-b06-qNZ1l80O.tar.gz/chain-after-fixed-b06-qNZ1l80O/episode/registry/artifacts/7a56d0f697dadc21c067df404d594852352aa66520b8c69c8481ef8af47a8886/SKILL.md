---
id: "dc535429-a159-4ed3-bbe4-f5f9f8fec6cc"
name: "standalone-python-config-validation-verification"
description: "Verifies standalone Python modules that perform import-time environment configuration validation while preserving a documented diagnostics contract. Use when reviewing such deliverables for single-source validation logic, complete failure reporting, runtime-only inputs, provenance accuracy, and behavioral tests."
version: "0.1.0"
tags:
  - "python"
  - "configuration"
  - "environment"
  - "diagnostics"
  - "testing"
  - "verification"
triggers:
  - "verify standalone Python config validation"
  - "review import-time environment validation"
  - "check diagnostics routine delegation"
  - "validate missing configuration error reporting"
  - "audit configuration module provenance"
---

# standalone-python-config-validation-verification

Verifies standalone Python modules that perform import-time environment configuration validation while preserving a documented diagnostics contract. Use when reviewing such deliverables for single-source validation logic, complete failure reporting, runtime-only inputs, provenance accuracy, and behavioral tests.

## Prompt

# Goal
Verify a standalone Python configuration-validation deliverable that adapts a documented diagnostics convention into import-time validation, and report whether it faithfully satisfies the convention and requested acceptance checks.

# Constraints & Style
- Verify the actual implementation and reproduce its behavior with commands; do not accept artifact claims without checking them.
- Treat unset, empty-string, and whitespace-only environment values as validation failures.
- Ensure one shared diagnostics routine is the sole owner of per-variable set/non-empty classification and missing-variable reporting. The application-facing configuration module must import that routine rather than duplicate the logic.
- On failure, raise one configuration error that lists every missing or empty required variable and includes a per-variable status for `ok`, `missing`, or `empty`.
- Read deployment-specific values, endpoints, credentials, and hosts only from runtime environment or configuration. Never hardcode them.
- If the underlying convention exists only as skill documentation rather than a deployed library or script, state that limitation explicitly and do not claim that a newly created module is the deployed standard.
- Verify provenance paths, quoted contract wording, and line references against the actual on-disk source. Correct false provenance claims rather than merely repeating them.
- Keep implementation and runtime inputs generic; do not invent unavailable endpoints, credentials, libraries, units, or supporting files.
- Report concise, evidence-backed findings and distinguish configuration failure from unrelated or unsupported functionality.

# Workflow
1. Locate the application module, shared diagnostics routine, tests, and any documented convention; confirm whether a deployed implementation actually exists.
2. Read the source and check that the application module delegates classification and reporting to the shared routine.
3. Inspect for hardcoded runtime values and verify that required values come from the process environment or injected environment mapping.
4. Exercise successful validation with all required values present.
5. Exercise failures with a required variable unset, set to an empty string, and set to whitespace only.
6. Exercise a case with multiple missing variables and confirm one error reports all of them together.
7. Run the supplied test suite and compilation or syntax checks appropriate to the implementation.
8. Compare the implementation and documentation against the real convention, correcting any inaccurate path, quote, line number, or deployment-status claim.
9. Report accepted behavior, corrections made, unsupported functionality that was deliberately excluded, and the commands or observable results supporting each conclusion.

## Triggers

- verify standalone Python config validation
- review import-time environment validation
- check diagnostics routine delegation
- validate missing configuration error reporting
- audit configuration module provenance
