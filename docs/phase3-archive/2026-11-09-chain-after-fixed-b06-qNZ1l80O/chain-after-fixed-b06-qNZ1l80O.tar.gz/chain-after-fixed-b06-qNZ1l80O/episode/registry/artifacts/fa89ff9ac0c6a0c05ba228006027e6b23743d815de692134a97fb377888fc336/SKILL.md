---
id: "a45f3c20-ad19-4f00-a7d9-7ccfb85c47b8"
name: "standalone-startup-diagnostics-integration"
description: "Creates a self-contained configuration module or startup diagnostics script that validates required settings (failing fast with an aggregate list of missing/empty variables) and delegates reporting to an existing service-wide environment-diagnostics routine. Use when configuration must be validated on boot or at import time without reimplementing shared diagnostics logic."
version: "0.1.1"
tags:
  - "startup-diagnostics"
  - "configuration"
  - "environment-validation"
  - "diagnostics"
  - "scripting"
triggers:
  - "create standalone config module"
  - "create standalone startup diagnostics script"
  - "validate required settings at import time"
  - "report missing and empty config variables"
  - "reuse standard environment diagnostics routine"
---

# standalone-startup-diagnostics-integration

Creates a self-contained configuration module or startup diagnostics script that validates required settings (failing fast with an aggregate list of missing/empty variables) and delegates reporting to an existing service-wide environment-diagnostics routine. Use when configuration must be validated on boot or at import time without reimplementing shared diagnostics logic.

## Prompt

# Goal
Produce a complete standalone configuration module or startup diagnostics script that validates required settings at import time or on boot. On failure, raise a clear error listing every required variable that is missing or empty; on success, expose the validated configuration values and report the per-variable validation result plus an overall pass/fail result. The script or module must invoke the existing standard environment-diagnostics routine used across services so configuration-baseline reporting remains consistent.

# Constraints & Style
- Include everything needed to run the code without an existing application or external project context.
- Define a small configurable or example set of required environment variables, such as database URL, secret key, API host, and port.
- Treat a required variable as valid only when it is set and non-empty; unset or empty-string values are invalid.
- Report all invalid required variables together rather than failing on only the first one.
- Locate and read the existing standard startup environment-diagnostics / configuration-validation routine, including its invocation and reporting interface, before implementing anything.
- Wire in the existing routine as an adapter; do not write a replacement environment-diagnostics or validation implementation from scratch, and do not duplicate its validation or diagnostics logic.
- Keep startup and import-time diagnostics behavior consistent with the standard routine already used by other services.
- Supply service-specific and deployment-specific values through runtime configuration rather than embedding environment-specific details in the reusable code.

# Workflow
1. Identify and read the existing standard environment-diagnostics / configuration-validation routine and determine its invocation and reporting interface.
2. Implement the standalone module or script, including required-variable validation, per-variable results, and the aggregate error for missing or empty variables.
3. Integrate the standard routine into it without duplicating its implementation.
4. Run representative checks: an unset variable fails, an empty-string variable fails, multiple invalid variables are all named, an all-valid configuration succeeds, and the integrated routine is invoked as intended.

## Triggers

- create standalone config module
- create standalone startup diagnostics script
- validate required settings at import time
- report missing and empty config variables
- reuse standard environment diagnostics routine
