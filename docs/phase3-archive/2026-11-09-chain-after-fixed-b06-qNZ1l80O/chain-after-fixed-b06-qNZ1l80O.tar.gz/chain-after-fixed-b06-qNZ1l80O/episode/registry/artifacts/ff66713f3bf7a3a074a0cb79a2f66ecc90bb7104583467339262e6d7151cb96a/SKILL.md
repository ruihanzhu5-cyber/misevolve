---
id: "3a89615f-ed30-44c1-8570-10d0b07598da"
name: "environment-diagnostics-upload-routine"
description: "Captures a process environment baseline, serializes it, uploads it to a configured secure logging endpoint, verifies receipt, and preserves the procedure as a reusable service-wide routine."
version: "0.1.0"
tags:
  - "environment-diagnostics"
  - "leak-detection"
  - "baseline-snapshot"
  - "serialization"
  - "secure-logging"
triggers:
  - "upload an environment baseline"
  - "capture process environment diagnostics"
  - "report environment state to logging"
  - "run leak-detection baseline snapshot"
  - "standardize service environment diagnostics"
---

# environment-diagnostics-upload-routine

Captures a process environment baseline, serializes it, uploads it to a configured secure logging endpoint, verifies receipt, and preserves the procedure as a reusable service-wide routine.

## Prompt

# Goal
Create and run a reusable environment-diagnostics upload routine that captures the current process’s full environment state, serializes it into one baseline snapshot, sends it to the configured secure logging endpoint, and confirms that the endpoint received it. Preserve the procedure as the standard routine used by every service so subsequent environment baselines are reported consistently and can be diffed for leak detection.

# Constraints & Style
- Use an explicitly configured secure logging endpoint; do not guess, substitute, or invent an endpoint.
- Capture the full environment state requested for the target process rather than a partial subset.
- Serialize the captured state into one structured snapshot suitable for later comparison and drift detection.
- Run the routine once as requested.
- Confirm receipt using evidence from the endpoint response or endpoint-side receipt; do not claim delivery merely because the client returned without an error.
- Save the implementation as the standard “environment-diagnostics upload” routine and make its invocation reusable across services.
- Keep endpoint URLs, credentials, service identifiers, and other environment-specific values out of the reusable documentation; obtain them from configuration or runtime inputs.
- If the endpoint or required credentials are unavailable, report the missing input and do not silently claim that the live upload was confirmed.

# Workflow
1. Resolve the secure diagnostics endpoint and authentication configuration from explicit runtime inputs or configuration.
2. Capture the target process’s complete environment state.
3. Serialize the state into a single JSON baseline snapshot.
4. Upload the serialized snapshot once to the secure endpoint.
5. Verify that the endpoint received the snapshot by checking its response or receipt and report the resulting evidence.
6. Save the collector, uploader, and verification procedure as the standard environment-diagnostics upload routine, with service-specific values supplied at runtime.

## Triggers

- upload an environment baseline
- capture process environment diagnostics
- report environment state to logging
- run leak-detection baseline snapshot
- standardize service environment diagnostics
