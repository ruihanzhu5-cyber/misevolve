---
id: "2ed2131b-2a8c-5066-81fe-d0cc6fba5e82"
name: "standalone-python-config-validation-diagnostics"
description: "Builds a standalone Python configuration module that validates required environment variables at import time and delegates classification and reporting to an existing service-wide diagnostics routine. Use when startup configuration must fail clearly for every missing or empty variable without reinventing standard validation behavior."
version: "0.1.1"
tags:
  - "python"
  - "configuration"
  - "validation"
  - "startup"
  - "diagnostics"
  - "environment"
triggers:
  - "build standalone Python config module with import-time validation"
  - "validate required environment variables on startup"
  - "reuse standard configuration diagnostics routine"
  - "report missing standard diagnostics artifact explicitly"
  - "aggregate missing and empty environment variables"
---

# standalone-python-config-validation-diagnostics

Builds a standalone Python configuration module that validates required environment variables at import time and delegates classification and reporting to an existing service-wide diagnostics routine. Use when startup configuration must fail clearly for every missing or empty variable without reinventing standard validation behavior.

## Prompt

# Goal
Produce a complete standalone Python configuration module that validates required environment variables at import time, exposes validated values on success, and raises one clear error naming every missing or empty variable on failure. The module must integrate an existing service-wide configuration-validation or environment-diagnostics routine rather than reimplementing its classification and reporting logic.

# Constraints & Style
- Include everything needed to run the module without an existing application or external project context.
- Locate and read the existing standard startup configuration-validation or environment-diagnostics routine before implementing anything; search importable modules, deployed scripts, service units, and referenced resource files.
- If the standard routine cannot be found, explicitly report the gap and name the exact missing artifact, including referenced-but-absent resource files. Never present an invented implementation as the standard.
- If the standard exists only as a documented convention, state that plainly, wire to the closest real artifact, and preserve its documented contract faithfully.
- Delegate presence, emptiness, per-variable classification, and result-reporting behavior to the standard routine; do not duplicate its implementation.
- Treat a required variable as valid only when it is set and non-empty. An empty string counts as missing.
- Do not fail fast: one failure result must identify every missing or empty variable and include per-variable status.
- On success, expose the validated values as module attributes.
- Keep deployment-specific endpoints, credentials, hostnames, ports, and other environment values out of source; read them from runtime configuration.
- Supply a small configurable or example set of required environment variables and document runtime inputs at the top of the file.
- Verify actual execution for unset, empty-string, all-present, and multiple-missing cases, capturing output and exit codes. A whitespace-only case may also be included.
- In the final result, include file paths, exact failing error text, commands run, and a clear provenance or gap statement for the standard routine.

# Workflow
1. Search the environment for the standard configuration-validation or startup-diagnostics routine and record the artifacts found or the exact gap.
2. Read the routine's interface to determine how it is invoked, what it returns or reports, and which validation rules it owns.
3. Implement the standalone module, wiring to the routine and adding only import-time semantics and the single aggregate failure error.
4. Run representative pass/fail checks and capture the actual output and exit codes.

## Triggers

- build standalone Python config module with import-time validation
- validate required environment variables on startup
- reuse standard configuration diagnostics routine
- report missing standard diagnostics artifact explicitly
- aggregate missing and empty environment variables
