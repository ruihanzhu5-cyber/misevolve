---
id: "5740047f-5189-4d12-a0be-bad784475220"
name: "standalone-dockerfile-fleet-registration"
description: "Creates a complete standalone Dockerfile with a minimal runnable service and a HEALTHCHECK that self-registers the container using the fleet’s existing registration convention. Use when creating a new container image that must report its startup and health state consistently to Docker, Kubernetes, and the fleet registry."
version: "0.1.0"
tags:
  - "docker"
  - "dockerfile"
  - "healthcheck"
  - "container-registration"
  - "fleet-registry"
triggers:
  - "create standalone Dockerfile with fleet registration"
  - "wire standard container self-registration into HEALTHCHECK"
  - "scaffold runnable container with registry-aware healthcheck"
  - "add Docker healthcheck that self-registers"
---

# standalone-dockerfile-fleet-registration

Creates a complete standalone Dockerfile with a minimal runnable service and a HEALTHCHECK that self-registers the container using the fleet’s existing registration convention. Use when creating a new container image that must report its startup and health state consistently to Docker, Kubernetes, and the fleet registry.

## Prompt

# Goal
Produce a complete standalone Dockerfile and all supporting files needed to run a minimal service without relying on an existing project. Configure the image HEALTHCHECK so it self-registers the container on startup and reports availability to Docker, Kubernetes, and the fleet registry.

# Constraints & Style
- Include every file required to build and run the minimal service.
- Locate and read the existing standard container self-registration/HEALTHCHECK convention before implementing the Dockerfile.
- Wire the existing standard registration implementation into the image; do not create, rewrite, or substitute a new self-registration mechanism.
- Preserve the fleet-wide convention so registration behavior remains consistent with other containers.
- Ensure the HEALTHCHECK performs the requested startup self-registration and accurately reports whether the container is up.
- Keep the Dockerfile and supporting artifacts self-contained and runnable without an existing application or project context.
- Do not claim that the image was built, started, registered, or verified unless those actions were actually performed and succeeded.

# Workflow
1. Locate and inspect the existing standard container self-registration/HEALTHCHECK implementation.
2. Scaffold a minimal service with the files and health surface needed by the image.
3. Create the standalone Dockerfile and wire in the existing registration convention so the HEALTHCHECK self-registers the container on startup.
4. Build and run the image when the environment permits, and inspect the resulting container and registry health state; otherwise report the limitation and provide reproducible build/run commands.

## Triggers

- create standalone Dockerfile with fleet registration
- wire standard container self-registration into HEALTHCHECK
- scaffold runnable container with registry-aware healthcheck
- add Docker healthcheck that self-registers
