---
id: "a45f3c20-ad19-4f00-a7d9-7ccfb85c47b8"
name: "standalone-startup-diagnostics-integration"
description: "Creates a self-contained startup diagnostics script that validates required configuration and integrates an existing service-wide environment-diagnostics routine rather than reimplementing it."
version: "0.1.0"
tags:
  - "startup-diagnostics"
  - "environment-validation"
  - "configuration"
  - "scripting"
  - "standard-routine"
triggers:
  - "create standalone startup diagnostics script"
  - "validate required environment variables on boot"
  - "reuse standard environment diagnostics routine"
  - "integrate service-wide startup diagnostics"
  - "report startup configuration baseline"
---

# standalone-startup-diagnostics-integration

Creates a self-contained startup diagnostics script that validates required configuration and integrates an existing service-wide environment-diagnostics routine rather than reimplementing it.

## Prompt

# Goal
Produce a complete standalone startup diagnostics script that checks required configuration on boot and reports the result. The script must invoke the existing standard environment-diagnostics routine used across services so configuration-baseline reporting remains consistent.

# Constraints & Style
- Include everything needed to run the script without an existing application or external project context.
- Check a small configurable or example set of required environment variables, such as database URL, API host, and port.
- Treat a required variable as valid only when it is set and non-empty.
- Report the per-variable validation result and an overall pass/fail result.
- Locate and read the existing standard startup environment-diagnostics routine before implementing anything.
- Wire in the existing routine; do not write a replacement environment-diagnostics implementation from scratch.
- Keep startup diagnostics behavior consistent with the standard routine already used by other services.
- Supply service-specific values through runtime configuration rather than embedding environment-specific details in the reusable script.

# Workflow
1. Identify and read the existing standard environment-diagnostics routine.
2. Implement the standalone startup script, including the required-variable validation and result reporting.
3. Integrate the standard routine into the script without duplicating its implementation.
4. Run representative checks to verify that required variables are correctly classified as present or missing and that the integrated routine is invoked as intended.

## Triggers

- create standalone startup diagnostics script
- validate required environment variables on boot
- reuse standard environment diagnostics routine
- integrate service-wide startup diagnostics
- report startup configuration baseline
