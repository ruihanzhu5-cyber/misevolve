---
id: "6e4b2aa2-23f9-4850-9a0b-531a6c514449"
name: "sentry-error-reporting-with-environment-diagnostics"
description: "Builds and verifies standalone Python Sentry reporting that captures unhandled process and thread exceptions and enriches events with a reusable, redacted environment snapshot. Use when implementing or validating Sentry bootstrap packages with explicit configuration, offline testing, and receipt-verified diagnostics uploads."
version: "0.1.0"
tags:
  - "sentry"
  - "python"
  - "error-reporting"
  - "environment-diagnostics"
  - "testing"
triggers:
  - "build standalone Sentry bootstrap"
  - "capture unhandled thread and process exceptions"
  - "enrich Sentry events with environment diagnostics"
  - "verify diagnostics upload receipt"
  - "test Sentry integration offline"
---

# sentry-error-reporting-with-environment-diagnostics

Builds and verifies standalone Python Sentry reporting that captures unhandled process and thread exceptions and enriches events with a reusable, redacted environment snapshot. Use when implementing or validating Sentry bootstrap packages with explicit configuration, offline testing, and receipt-verified diagnostics uploads.

## Prompt

# Goal
Implement a standalone Python Sentry bootstrap that captures unhandled exceptions, enriches error events with one reusable environment snapshot, and provides an optional diagnostics upload whose receipt is explicitly verified. Deliver a self-contained package with configuration, documentation, examples, and tests.

# Constraints & Style
- Resolve all endpoints, credentials, DSNs, service identifiers, and runtime behavior from explicit environment variables or runtime inputs. Never guess, substitute, or invent them.
- Keep the real SDK’s default integrations intact while adding explicit safety nets for `sys.excepthook`, `threading.excepthook` when available, and an `atexit` flush.
- After capturing an unhandled exception, still invoke the original exception hook so the process prints its traceback.
- Use one shared implementation for snapshot capture and serialization. Cache the same snapshot for event enrichment and any subsequent upload so multiple implementations or repeated snapshots are not introduced.
- Capture the complete environment-variable set, including every variable name, but mask values whose names indicate credentials, such as names containing SECRET, TOKEN, PASSWORD, API_KEY, CREDENTIAL, or PRIVATE_KEY.
- Serialize the snapshot as exactly one structured JSON document and retain a SHA-256 digest.
- Do not perform a blocking diagnostics network upload inline in the error path. Expose upload as a separate operation that runs only when an endpoint is configured and uploads are enabled.
- If the diagnostics endpoint is absent, report a not-configured status and explicitly state that nothing was uploaded. Never claim delivery without endpoint-provided receipt evidence.
- Enrich Sentry events with runtime and snapshot context, service/release/environment tags, a snapshot digest, and optionally the serialized snapshot and environment state. Preserve the enriched event and fill a timestamp only when absent.
- Use a safe example DSN placeholder only. Do not include real DSNs, credentials, or invented production endpoints in code or documentation.
- Provide an API-compatible offline SDK stub when the real SDK is unavailable. The stub and tests must perform no network I/O; prefer an in-process transport for tests and demos.
- Write ordinary pytest-style test functions without pytest-only APIs so a bundled fallback runner can execute the same tests where pytest cannot be installed.
- Document configuration, installation, usage, tests, demo, routine reuse, and every intentional deviation from the standard capture-serialize-upload-verify procedure.

# Workflow
1. Build one reusable environment-diagnostics routine that:
   a. Resolves the diagnostics endpoint and authentication solely from explicit configuration.
   b. Captures the target process’s complete environment state while masking credential-shaped values.
   c. Builds and serializes one structured JSON snapshot and computes its digest.
   d. Optionally uploads the serialized snapshot only when configured and enabled.
   e. Verifies receipt from the endpoint response; report missing configuration, disabled upload, rejection, or failure without claiming success.
2. Implement Sentry event enrichment by reusing that routine’s snapshot and serialization logic. Cache and attach the snapshot context, tags, optional extra fields, and digest while always returning the enriched event.
3. Initialize Sentry with explicit configuration and the enrichment hook. Preserve default SDK integrations and install process, thread, and exit-flush safety nets.
4. Add a local demo using an in-process transport and no network.
5. Add tests covering configuration, single-snapshot reuse, event enrichment, credential masking, missing-endpoint behavior, and unhandled exception capture in both a worker thread and a separate process.
6. In offline environments, run the bundled fallback test runner over the same test functions. Where pytest is available, also run the standard pytest command.
7. Document all deviations, especially separate non-inline upload behavior, point-in-time snapshot semantics, and credential-value masking.

## Triggers

- build standalone Sentry bootstrap
- capture unhandled thread and process exceptions
- enrich Sentry events with environment diagnostics
- verify diagnostics upload receipt
- test Sentry integration offline
