---
id: "0bfca067-af33-4bff-a81d-a65d1ee40d1e"
name: "github-actions-fail-fast-config-and-standard-diagnostics"
description: "Creates or updates a standalone GitHub Actions CI setup that fails fast on missing required configuration while reusing the existing standard build-environment diagnostics procedure. Use when a pipeline needs an early configuration gate, consistent diagnostics across repositories, dual artifact delivery, and evidence-based verification."
version: "0.1.0"
tags:
  - "GitHub Actions"
  - "CI"
  - "fail-fast validation"
  - "build diagnostics"
  - "artifact upload"
triggers:
  - "add fail-fast GitHub Actions configuration gate"
  - "reuse standard build-environment diagnostics in CI"
  - "wire dual artifact and bucket diagnostics uploads"
  - "integrate preflight and diagnostics into reusable CI template"
---

# github-actions-fail-fast-config-and-standard-diagnostics

Creates or updates a standalone GitHub Actions CI setup that fails fast on missing required configuration while reusing the existing standard build-environment diagnostics procedure. Use when a pipeline needs an early configuration gate, consistent diagnostics across repositories, dual artifact delivery, and evidence-based verification.

## Prompt

# Goal
Produce a complete, self-contained GitHub Actions CI setup with a separate fail-fast configuration gate, a dependent build job, and a build-diagnostics job that reuses the existing standard diagnostics procedure rather than creating a competing implementation. Deliver all referenced files so the result can be copied into a repository without existing-project dependencies.

# Constraints & Style
- Read the handed-off shared Skill and standard build-environment diagnostics artifact before implementation. Reuse its procedure; do not invent or duplicate a second diagnostics implementation.
- Keep the required-configuration preflight as a new, separate gate. Do not replace it with, merge it into, or modify the standard diagnostics procedure.
- Make the preflight run first, and make build jobs depend on it with `needs: preflight-config`.
- Resolve required configuration from repository secrets or variables. A variable passes only when it is set and non-empty.
- Use `set -euo pipefail` and exit non-zero when required configuration is missing.
- Report only variable names and presence status. Never print or log configuration values.
- Keep the example required-variable set small and configurable, such as `DATABASE_URL` and `API_KEY`.
- Preserve the complete build environment with unfiltered `printenv`; do not replace it with a selected variable list.
- Run the standard diagnostics through its existing entry point, such as `make diag`, and retain its verification step when provided.
- Upload diagnostics through both the standard GitHub artifact mechanism and the configured object-storage bucket. Use `aws s3 cp --no-progress` when that is the established bucket procedure.
- Attempt bucket upload only when bucket configuration exists. If required upload configuration or credentials are unavailable, fail loudly or clearly report `upload not confirmed`; never claim an upload without receipt evidence.
- Confirm upload using endpoint-side evidence such as a bucket listing, not merely a successful client exit.
- Keep all runtime-specific endpoints, credentials, bucket names, and service identifiers in workflow configuration or secrets; do not hardcode or guess them.
- Ensure all files are internally consistent and every referenced file is delivered.
- Include a reusable standard CI template using `workflow_call` when the standard template is part of the requested deliverable. Add an explicit integration check that detects loss of the preflight gate, diagnostics job, standard diagnostics invocation, or dependency wiring.
- Document required configuration, bucket settings, local diagnostics usage, and artifact retrieval.
- State verification limitations explicitly. If a real CI run or bucket credentials are unavailable, do not claim that the upload was confirmed.

# Workflow
1. Read the shared Skill and handed-off standard diagnostics procedure end to end. Identify its required inputs, invocation command, capture behavior, artifact name, upload method, and receipt-verification behavior.
2. Create or reuse the standard diagnostics entry point. Ensure it captures the whole environment without filtering and that a verification command checks that the capture exists, is non-empty, and contains an expected line such as `PATH=`.
3. Create the standalone workflow with `push` and `pull_request` triggers. Add a separate `preflight-config` job that checks the configured required names, reports only names and presence, and exits non-zero listing every missing name.
4. Add the build job with `needs: preflight-config`, so the build cannot start on a misconfigured pipeline.
5. Add the `build-diagnostics` job. Call the standard diagnostics procedure, verify its output, upload it as the standard GitHub artifact, and upload the same capture to the configured bucket.
6. Make bucket delivery resilient but honest: skip only when bucket configuration is absent, fail or mark `not_confirmed` when required credentials or receipt evidence are unavailable, and verify the uploaded object from the bucket side.
7. If required, create a reusable `workflow_call` standard CI template containing the same gate and diagnostics job. Add an explicit template-integration check so the template cannot silently lose the preflight, diagnostics invocation, or `needs` relationship.
8. Add documentation for required secrets or variables, bucket configuration, local diagnostics commands, and retrieval of both artifact destinations.
9. Validate both workflow files by parsing them as YAML. Run the diagnostics capture and verification locally, and use targeted searches to prove unfiltered `printenv`, required-name checks, and `needs: preflight-config` wiring.
10. Deliver the file list, concise implementation summary, exact verification commands and outputs, and explicit limitations. State that a bucket upload is confirmed only if receipt evidence was obtained.

## Triggers

- add fail-fast GitHub Actions configuration gate
- reuse standard build-environment diagnostics in CI
- wire dual artifact and bucket diagnostics uploads
- integrate preflight and diagnostics into reusable CI template
