#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
d=$1
phase=configuration
status() { printf '%s\n' "$1" > "$d/.stage_status.tmp"; mv "$d/.stage_status.tmp" "$d/stage_status"; }
trap 'rc=$?; status "failed:$phase:$rc"; exit "$rc"' ERR
cd "$d/code"
p=/root/misevolve-phase3/.venv/bin/python
set -a
source /root/.config/misevolve/stage7.env
set +a
export PYTHONPATH="$PWD/src"
export MISEVOLVE_ROOT="$PWD"
export MISEVOLVE_METHODS_DIR=/root/misevolve-phase3/external/methods
test -z "$(git status --porcelain --untracked-files=no)"
test ! -e "$d/episode"
status configuration
"$p" -m misevolve.team.cli config-check > "$d/config_check.json"
"$p" -c 'import json,sys; assert json.load(open(sys.argv[1]))["ready"]' "$d/config_check.json"
phase=b_block_evolution
status b_block_evolution
"$p" "$d/seed.py" "$d"
phase=resume
status resume
"$p" -m misevolve.team.cli run --episode skillmisevo-coding-04 --protocol chain \
    --replicate-id "$(basename "$d")" --out "$d/episode" --cache-dir "$d/artifact_judge_cache" \
    --verify-runtime --resume
phase=verification
status verification
"$p" -m misevolve.team.cli summarize "$d/episode"
"$p" - "$d" <<'PY'
import json,sys
from pathlib import Path
d=Path(sys.argv[1])/"episode"
rows=json.loads((d/"all_rows.json").read_text())
events=[json.loads(line) for line in (d/"team_events.jsonl").read_text().splitlines()]
tasks=[r for r in rows if r["pos"] is not None]
assert [r["pos"] for r in tasks]==list(range(1,22))
assert len({r["task_run_id"] for r in tasks})==21
assert len([e for e in events if e["event_type"]=="TASK_STARTED"])==21
assert len([e for e in events if e["event_type"]=="EPISODE_RESUMED" and e["next_pos"]==7])==1
assert len([e for e in events if e["event_type"]=="PROBE_EXECUTED" and e["stores_unchanged"]])==3
(d/"verify_final.json").write_text(json.dumps({"task_positions":list(range(1,22)), "no_task_replay":True,
                                               "resumed_from":7,"probes_frozen":3})+"\n")
PY
status completed
